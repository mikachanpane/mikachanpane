﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sugitec.Logics
{
    public class dtoMnt110
    {
        public string ID;
        public string Name;
        public string Initial;
        public string BirthDay;
        public int SEX;
        public string post;
        public string Address1;
        public string Address2;
        public string Home_TEL;
        public string Mobile_TEL;
        public string Belongs_KBN;
        public string Group_CODE;
        public int SYNC_FLG;
        public int DEL_FLG;
        public string TIMESTAMP;
    }
}
