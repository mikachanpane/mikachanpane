﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sugitec.Logics
{
    public class dtoMnt120
    {
        public string Code;
        public string Name;
        public string KotsuKBN;
        public decimal perdiem = 0;
        public decimal accomodation = 0;
        public int SYNC_FLG;
        public int DEL_FLG;
        public string TIMESTAMP;
    }
}
