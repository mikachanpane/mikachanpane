﻿using System;
using System.Text;

namespace Sugitec.Logics
{
	public class dtoInq010
	{
		/// <summary>売上年月日</summary>
		public string SALES_YM = string.Empty;
	}
}
