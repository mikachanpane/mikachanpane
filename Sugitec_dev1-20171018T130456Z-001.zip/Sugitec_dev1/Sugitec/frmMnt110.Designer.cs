﻿namespace Sugitec
{
    partial class frmMnt110
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Sugitec.Common.HeaderCell headerCell23 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell24 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell25 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell26 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell27 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell28 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell29 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell30 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell31 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell32 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell33 = new Sugitec.Common.HeaderCell();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Address1 = new Sugitec.Common.ctlBytTextBoxEx();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_initial = new Sugitec.Common.ctlBytTextBoxEx();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_name = new Sugitec.Common.ctlBytTextBoxEx();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dgv = new Sugitec.Common.ucDataGridViewEx();
            this.dgv_del = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgv_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_initial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_birthday = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_sex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_zip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_TEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_mobileTEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_belongs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_GROUPCD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_Address1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_address2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.Cmd_End = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.dtp_birthday = new Sugitec.Common.ctlDateTimePickerEx();
            this.cmb_belongs = new System.Windows.Forms.ComboBox();
            this.grp_Sex = new System.Windows.Forms.GroupBox();
            this.rd_female = new System.Windows.Forms.RadioButton();
            this.rd_male = new System.Windows.Forms.RadioButton();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txt_zipcd = new Sugitec.Common.ucNumTextBox();
            this.txt_mobileNo = new Sugitec.Common.ucNumTextBox();
            this.txt_TelNo = new Sugitec.Common.ucNumTextBox();
            this.txt_ID = new Sugitec.Common.ucNumTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_GROUPCD = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_Address2 = new Sugitec.Common.ctlBytTextBoxEx();
            this.btncopy1 = new System.Windows.Forms.Button();
            this.btncopy2 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.grp_Sex.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.GreenYellow;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Location = new System.Drawing.Point(318, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "住所";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_Address1
            // 
            this.txt_Address1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.txt_Address1.Location = new System.Drawing.Point(429, 73);
            this.txt_Address1.Multiline = true;
            this.txt_Address1.Name = "txt_Address1";
            this.txt_Address1.OldText = null;
            this.txt_Address1.Size = new System.Drawing.Size(378, 20);
            this.txt_Address1.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.GreenYellow;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(318, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "郵便番号";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.GreenYellow;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(12, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "イニシャル";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_initial
            // 
            this.txt_initial.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txt_initial.Location = new System.Drawing.Point(108, 99);
            this.txt_initial.Name = "txt_initial";
            this.txt_initial.OldText = null;
            this.txt_initial.Size = new System.Drawing.Size(60, 20);
            this.txt_initial.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.GreenYellow;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(12, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "氏名";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_name
            // 
            this.txt_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txt_name.ImeMode = System.Windows.Forms.ImeMode.On;
            this.txt_name.Location = new System.Drawing.Point(108, 73);
            this.txt_name.Name = "txt_name";
            this.txt_name.OldText = null;
            this.txt_name.Size = new System.Drawing.Size(191, 20);
            this.txt_name.TabIndex = 3;
            this.txt_name.Text = "８８８８８８８８８８８";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.GreenYellow;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(12, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "技術者ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.GreenYellow;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Location = new System.Drawing.Point(318, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "自宅電話番号";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.GreenYellow;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Location = new System.Drawing.Point(561, 128);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 20);
            this.label9.TabIndex = 16;
            this.label9.Text = "携帯電話番号";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.GreenYellow;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(12, 128);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 20);
            this.label10.TabIndex = 6;
            this.label10.Text = "生年月日";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AllowUserToResizeRows = false;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.ColumnHeaderBorderStyle = Sugitec.Common.ucDataGridViewEx.HeaderCellBorderStyle.SingleLine;
            this.dgv.ColumnHeaderRowCount = 1;
            this.dgv.ColumnHeaderRowHeight = 20;
            this.dgv.ColumnHeadersHeight = 22;
            this.dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgv_del,
            this.dgv_ID,
            this.dgv_name,
            this.dgv_initial,
            this.dgv_birthday,
            this.dgv_sex,
            this.dgv_zip,
            this.dgv_TEL,
            this.dgv_mobileTEL,
            this.dgv_belongs,
            this.dgv_GROUPCD,
            this.dgv_Address1,
            this.dgv_address2});
            headerCell23.BackgroundColor = System.Drawing.Color.Empty;
            headerCell23.Column = 0;
            headerCell23.ColumnSpan = 1;
            headerCell23.ForeColor = System.Drawing.Color.Empty;
            headerCell23.Row = 0;
            headerCell23.RowSpan = 1;
            headerCell23.SortVisible = false;
            headerCell23.Text = "削除";
            headerCell23.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell23.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell24.BackgroundColor = System.Drawing.Color.Empty;
            headerCell24.Column = 1;
            headerCell24.ColumnSpan = 1;
            headerCell24.ForeColor = System.Drawing.Color.Empty;
            headerCell24.Row = 0;
            headerCell24.RowSpan = 1;
            headerCell24.SortVisible = false;
            headerCell24.Text = "技術者ID";
            headerCell24.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell24.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell25.BackgroundColor = System.Drawing.Color.Empty;
            headerCell25.Column = 2;
            headerCell25.ColumnSpan = 1;
            headerCell25.ForeColor = System.Drawing.Color.Empty;
            headerCell25.Row = 0;
            headerCell25.RowSpan = 1;
            headerCell25.SortVisible = false;
            headerCell25.Text = "氏名";
            headerCell25.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell25.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell26.BackgroundColor = System.Drawing.Color.Empty;
            headerCell26.Column = 3;
            headerCell26.ColumnSpan = 1;
            headerCell26.ForeColor = System.Drawing.Color.Empty;
            headerCell26.Row = 0;
            headerCell26.RowSpan = 1;
            headerCell26.SortVisible = false;
            headerCell26.Text = "イニシャル";
            headerCell26.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell26.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell27.BackgroundColor = System.Drawing.Color.Empty;
            headerCell27.Column = 4;
            headerCell27.ColumnSpan = 1;
            headerCell27.ForeColor = System.Drawing.Color.Empty;
            headerCell27.Row = 0;
            headerCell27.RowSpan = 1;
            headerCell27.SortVisible = false;
            headerCell27.Text = "生年月日";
            headerCell27.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell27.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell28.BackgroundColor = System.Drawing.Color.Empty;
            headerCell28.Column = 5;
            headerCell28.ColumnSpan = 1;
            headerCell28.ForeColor = System.Drawing.Color.Empty;
            headerCell28.Row = 0;
            headerCell28.RowSpan = 1;
            headerCell28.SortVisible = false;
            headerCell28.Text = "性別";
            headerCell28.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell28.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell29.BackgroundColor = System.Drawing.Color.Empty;
            headerCell29.Column = 6;
            headerCell29.ColumnSpan = 1;
            headerCell29.ForeColor = System.Drawing.Color.Empty;
            headerCell29.Row = 0;
            headerCell29.RowSpan = 1;
            headerCell29.SortVisible = false;
            headerCell29.Text = "郵便番号";
            headerCell29.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell29.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell30.BackgroundColor = System.Drawing.Color.Empty;
            headerCell30.Column = 7;
            headerCell30.ColumnSpan = 1;
            headerCell30.ForeColor = System.Drawing.Color.Empty;
            headerCell30.Row = 0;
            headerCell30.RowSpan = 1;
            headerCell30.SortVisible = false;
            headerCell30.Text = "自宅電話番号";
            headerCell30.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell30.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell31.BackgroundColor = System.Drawing.Color.Empty;
            headerCell31.Column = 8;
            headerCell31.ColumnSpan = 1;
            headerCell31.ForeColor = System.Drawing.Color.Empty;
            headerCell31.Row = 0;
            headerCell31.RowSpan = 1;
            headerCell31.SortVisible = false;
            headerCell31.Text = "携帯電話番号";
            headerCell31.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell31.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell32.BackgroundColor = System.Drawing.Color.Empty;
            headerCell32.Column = 9;
            headerCell32.ColumnSpan = 1;
            headerCell32.ForeColor = System.Drawing.Color.Empty;
            headerCell32.Row = 0;
            headerCell32.RowSpan = 1;
            headerCell32.SortVisible = false;
            headerCell32.Text = "所属会社コード";
            headerCell32.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell32.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell33.BackgroundColor = System.Drawing.Color.Empty;
            headerCell33.Column = 10;
            headerCell33.ColumnSpan = 1;
            headerCell33.ForeColor = System.Drawing.Color.Empty;
            headerCell33.Row = 0;
            headerCell33.RowSpan = 1;
            headerCell33.SortVisible = false;
            headerCell33.Text = "住所";
            headerCell33.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell33.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            this.dgv.HeaderCells.Add(headerCell23);
            this.dgv.HeaderCells.Add(headerCell24);
            this.dgv.HeaderCells.Add(headerCell25);
            this.dgv.HeaderCells.Add(headerCell26);
            this.dgv.HeaderCells.Add(headerCell27);
            this.dgv.HeaderCells.Add(headerCell28);
            this.dgv.HeaderCells.Add(headerCell29);
            this.dgv.HeaderCells.Add(headerCell30);
            this.dgv.HeaderCells.Add(headerCell31);
            this.dgv.HeaderCells.Add(headerCell32);
            this.dgv.HeaderCells.Add(headerCell33);
            this.dgv.Location = new System.Drawing.Point(12, 251);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersVisible = false;
            this.dgv.RowTemplate.Height = 21;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv.Size = new System.Drawing.Size(822, 251);
            this.dgv.TabIndex = 24;
            this.dgv.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_CellMouseClick);
            // 
            // dgv_del
            // 
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.NullValue = false;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_del.DefaultCellStyle = dataGridViewCellStyle21;
            this.dgv_del.FalseValue = "0";
            this.dgv_del.HeaderText = "削除";
            this.dgv_del.Name = "dgv_del";
            this.dgv_del.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_del.TrueValue = "1";
            this.dgv_del.Width = 60;
            // 
            // dgv_ID
            // 
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_ID.DefaultCellStyle = dataGridViewCellStyle22;
            this.dgv_ID.HeaderText = "技術者ID";
            this.dgv_ID.Name = "dgv_ID";
            this.dgv_ID.ReadOnly = true;
            this.dgv_ID.Width = 90;
            // 
            // dgv_name
            // 
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_name.DefaultCellStyle = dataGridViewCellStyle23;
            this.dgv_name.HeaderText = "氏名";
            this.dgv_name.Name = "dgv_name";
            this.dgv_name.ReadOnly = true;
            this.dgv_name.Width = 150;
            // 
            // dgv_initial
            // 
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_initial.DefaultCellStyle = dataGridViewCellStyle24;
            this.dgv_initial.HeaderText = "イニシャル";
            this.dgv_initial.Name = "dgv_initial";
            this.dgv_initial.ReadOnly = true;
            // 
            // dgv_birthday
            // 
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_birthday.DefaultCellStyle = dataGridViewCellStyle25;
            this.dgv_birthday.HeaderText = "生年月日";
            this.dgv_birthday.Name = "dgv_birthday";
            this.dgv_birthday.ReadOnly = true;
            this.dgv_birthday.Width = 80;
            // 
            // dgv_sex
            // 
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_sex.DefaultCellStyle = dataGridViewCellStyle26;
            this.dgv_sex.HeaderText = "性別";
            this.dgv_sex.Name = "dgv_sex";
            this.dgv_sex.ReadOnly = true;
            this.dgv_sex.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_sex.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dgv_sex.Width = 40;
            // 
            // dgv_zip
            // 
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_zip.DefaultCellStyle = dataGridViewCellStyle27;
            this.dgv_zip.HeaderText = "郵便番号";
            this.dgv_zip.Name = "dgv_zip";
            this.dgv_zip.ReadOnly = true;
            this.dgv_zip.Width = 80;
            // 
            // dgv_TEL
            // 
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_TEL.DefaultCellStyle = dataGridViewCellStyle28;
            this.dgv_TEL.HeaderText = "自宅電話番号";
            this.dgv_TEL.Name = "dgv_TEL";
            this.dgv_TEL.ReadOnly = true;
            // 
            // dgv_mobileTEL
            // 
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_mobileTEL.DefaultCellStyle = dataGridViewCellStyle29;
            this.dgv_mobileTEL.HeaderText = "携帯電話番号";
            this.dgv_mobileTEL.Name = "dgv_mobileTEL";
            // 
            // dgv_belongs
            // 
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_belongs.DefaultCellStyle = dataGridViewCellStyle30;
            this.dgv_belongs.HeaderText = "所属区分";
            this.dgv_belongs.Name = "dgv_belongs";
            this.dgv_belongs.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dgv_belongs.Visible = false;
            this.dgv_belongs.Width = 120;
            // 
            // dgv_GROUPCD
            // 
            this.dgv_GROUPCD.HeaderText = "グループコード";
            this.dgv_GROUPCD.Name = "dgv_GROUPCD";
            this.dgv_GROUPCD.Visible = false;
            // 
            // dgv_Address1
            // 
            this.dgv_Address1.HeaderText = "住所1";
            this.dgv_Address1.Name = "dgv_Address1";
            this.dgv_Address1.ReadOnly = true;
            this.dgv_Address1.Visible = false;
            // 
            // dgv_address2
            // 
            this.dgv_address2.HeaderText = "住所2";
            this.dgv_address2.Name = "dgv_address2";
            this.dgv_address2.ReadOnly = true;
            this.dgv_address2.Visible = false;
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(516, 194);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 36);
            this.btn_OK.TabIndex = 20;
            this.btn_OK.Text = "確定";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(597, 194);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(75, 36);
            this.btn_clear.TabIndex = 21;
            this.btn_clear.Text = "クリア";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // Cmd_End
            // 
            this.Cmd_End.Location = new System.Drawing.Point(759, 194);
            this.Cmd_End.Name = "Cmd_End";
            this.Cmd_End.Size = new System.Drawing.Size(75, 36);
            this.Cmd_End.TabIndex = 23;
            this.Cmd_End.Text = "終了";
            this.Cmd_End.UseVisualStyleBackColor = true;
            this.Cmd_End.Click += new System.EventHandler(this.Cmd_End_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.GreenYellow;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Location = new System.Drawing.Point(318, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "所属区分";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtp_birthday
            // 
            this.dtp_birthday.Location = new System.Drawing.Point(108, 126);
            this.dtp_birthday.Name = "dtp_birthday";
            this.dtp_birthday.Size = new System.Drawing.Size(154, 20);
            this.dtp_birthday.TabIndex = 7;
            this.dtp_birthday.Value = new System.DateTime(2017, 5, 9, 14, 12, 41, 590);
            // 
            // cmb_belongs
            // 
            this.cmb_belongs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_belongs.FormattingEnabled = true;
            this.cmb_belongs.Location = new System.Drawing.Point(429, 157);
            this.cmb_belongs.Name = "cmb_belongs";
            this.cmb_belongs.Size = new System.Drawing.Size(126, 21);
            this.cmb_belongs.TabIndex = 19;
            // 
            // grp_Sex
            // 
            this.grp_Sex.Controls.Add(this.rd_female);
            this.grp_Sex.Controls.Add(this.rd_male);
            this.grp_Sex.Location = new System.Drawing.Point(108, 150);
            this.grp_Sex.Name = "grp_Sex";
            this.grp_Sex.Size = new System.Drawing.Size(100, 36);
            this.grp_Sex.TabIndex = 9;
            this.grp_Sex.TabStop = false;
            // 
            // rd_female
            // 
            this.rd_female.AutoSize = true;
            this.rd_female.Location = new System.Drawing.Point(51, 11);
            this.rd_female.Name = "rd_female";
            this.rd_female.Size = new System.Drawing.Size(39, 17);
            this.rd_female.TabIndex = 1;
            this.rd_female.Text = "女";
            this.rd_female.UseVisualStyleBackColor = true;
            // 
            // rd_male
            // 
            this.rd_male.AutoSize = true;
            this.rd_male.Checked = true;
            this.rd_male.Location = new System.Drawing.Point(6, 11);
            this.rd_male.Name = "rd_male";
            this.rd_male.Size = new System.Drawing.Size(39, 17);
            this.rd_male.TabIndex = 0;
            this.rd_male.TabStop = true;
            this.rd_male.Text = "男";
            this.rd_male.UseVisualStyleBackColor = true;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(678, 194);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 36);
            this.btn_delete.TabIndex = 22;
            this.btn_delete.Text = "削除";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // txt_zipcd
            // 
            this.txt_zipcd.BackColor = System.Drawing.SystemColors.Window;
            this.txt_zipcd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_zipcd.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericSymbol;
            this.txt_zipcd.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_zipcd.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_zipcd.Format = null;
            this.txt_zipcd.IllegalCharacter = null;
            this.txt_zipcd.Location = new System.Drawing.Point(429, 47);
            this.txt_zipcd.MaxLength = 8;
            this.txt_zipcd.Name = "txt_zipcd";
            this.txt_zipcd.OldText = null;
            this.txt_zipcd.Size = new System.Drawing.Size(126, 20);
            this.txt_zipcd.TabIndex = 11;
            this.txt_zipcd.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_zipcd.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.None;
            // 
            // txt_mobileNo
            // 
            this.txt_mobileNo.BackColor = System.Drawing.SystemColors.Window;
            this.txt_mobileNo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_mobileNo.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericSymbol;
            this.txt_mobileNo.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_mobileNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_mobileNo.Format = null;
            this.txt_mobileNo.IllegalCharacter = null;
            this.txt_mobileNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txt_mobileNo.Location = new System.Drawing.Point(678, 129);
            this.txt_mobileNo.MaxLength = 15;
            this.txt_mobileNo.Name = "txt_mobileNo";
            this.txt_mobileNo.OldText = null;
            this.txt_mobileNo.Size = new System.Drawing.Size(130, 20);
            this.txt_mobileNo.TabIndex = 17;
            this.txt_mobileNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_mobileNo.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.None;
            // 
            // txt_TelNo
            // 
            this.txt_TelNo.BackColor = System.Drawing.SystemColors.Window;
            this.txt_TelNo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_TelNo.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericSymbol;
            this.txt_TelNo.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_TelNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_TelNo.Format = null;
            this.txt_TelNo.IllegalCharacter = null;
            this.txt_TelNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txt_TelNo.Location = new System.Drawing.Point(429, 128);
            this.txt_TelNo.MaxLength = 15;
            this.txt_TelNo.Name = "txt_TelNo";
            this.txt_TelNo.OldText = null;
            this.txt_TelNo.Size = new System.Drawing.Size(126, 20);
            this.txt_TelNo.TabIndex = 15;
            this.txt_TelNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_TelNo.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.None;
            // 
            // txt_ID
            // 
            this.txt_ID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txt_ID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_ID.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
            this.txt_ID.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_ID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_ID.Format = null;
            this.txt_ID.IllegalCharacter = null;
            this.txt_ID.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txt_ID.Location = new System.Drawing.Point(108, 47);
            this.txt_ID.MaxLength = 8;
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.OldText = null;
            this.txt_ID.Size = new System.Drawing.Size(90, 20);
            this.txt_ID.TabIndex = 1;
            this.txt_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_ID.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.GreenYellow;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Location = new System.Drawing.Point(12, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "性別";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmb_GROUPCD
            // 
            this.cmb_GROUPCD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_GROUPCD.FormattingEnabled = true;
            this.cmb_GROUPCD.Location = new System.Drawing.Point(678, 157);
            this.cmb_GROUPCD.Name = "cmb_GROUPCD";
            this.cmb_GROUPCD.Size = new System.Drawing.Size(130, 21);
            this.cmb_GROUPCD.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.GreenYellow;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Location = new System.Drawing.Point(561, 158);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 20);
            this.label11.TabIndex = 25;
            this.label11.Text = "グループコード";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_Address2
            // 
            this.txt_Address2.ImeMode = System.Windows.Forms.ImeMode.On;
            this.txt_Address2.Location = new System.Drawing.Point(429, 99);
            this.txt_Address2.Multiline = true;
            this.txt_Address2.Name = "txt_Address2";
            this.txt_Address2.OldText = null;
            this.txt_Address2.Size = new System.Drawing.Size(378, 20);
            this.txt_Address2.TabIndex = 27;
            // 
            // btncopy1
            // 
            this.btncopy1.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btncopy1.Location = new System.Drawing.Point(6, 32);
            this.btncopy1.Name = "btncopy1";
            this.btncopy1.Size = new System.Drawing.Size(89, 21);
            this.btncopy1.TabIndex = 28;
            this.btncopy1.Text = "氏名・連絡先";
            this.btncopy1.UseVisualStyleBackColor = true;
            this.btncopy1.Click += new System.EventHandler(this.btnCopy1_Click);
            // 
            // btncopy2
            // 
            this.btncopy2.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btncopy2.Location = new System.Drawing.Point(104, 32);
            this.btncopy2.Name = "btncopy2";
            this.btncopy2.Size = new System.Drawing.Size(82, 21);
            this.btncopy2.TabIndex = 29;
            this.btncopy2.Text = "詳細";
            this.btncopy2.UseVisualStyleBackColor = true;
            this.btncopy2.Click += new System.EventHandler(this.btncopy2_Click);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.Control;
            this.label12.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.Location = new System.Drawing.Point(15, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(150, 20);
            this.label12.TabIndex = 30;
            this.label12.Text = "クリップボードにコピー";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.btncopy2);
            this.groupBox1.Controls.Add(this.btncopy1);
            this.groupBox1.Location = new System.Drawing.Point(318, 184);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(192, 61);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            // 
            // frmMnt110
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 527);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txt_Address2);
            this.Controls.Add(this.txt_Address1);
            this.Controls.Add(this.cmb_GROUPCD);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_mobileNo);
            this.Controls.Add(this.txt_TelNo);
            this.Controls.Add(this.txt_zipcd);
            this.Controls.Add(this.txt_ID);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.grp_Sex);
            this.Controls.Add(this.cmb_belongs);
            this.Controls.Add(this.dtp_birthday);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Cmd_End);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_initial);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.label1);
            this.Name = "frmMnt110";
            this.Text = "frmMNT100";
            this.Load += new System.EventHandler(this.frmMnt110_Load);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.txt_name, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.txt_initial, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.dgv, 0);
            this.Controls.SetChildIndex(this.btn_OK, 0);
            this.Controls.SetChildIndex(this.btn_clear, 0);
            this.Controls.SetChildIndex(this.Cmd_End, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.dtp_birthday, 0);
            this.Controls.SetChildIndex(this.cmb_belongs, 0);
            this.Controls.SetChildIndex(this.grp_Sex, 0);
            this.Controls.SetChildIndex(this.btn_delete, 0);
            this.Controls.SetChildIndex(this.txt_ID, 0);
            this.Controls.SetChildIndex(this.txt_zipcd, 0);
            this.Controls.SetChildIndex(this.txt_TelNo, 0);
            this.Controls.SetChildIndex(this.txt_mobileNo, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.cmb_GROUPCD, 0);
            this.Controls.SetChildIndex(this.txt_Address1, 0);
            this.Controls.SetChildIndex(this.txt_Address2, 0);
            this.Controls.SetChildIndex(this.groupBox1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.grp_Sex.ResumeLayout(false);
            this.grp_Sex.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private Sugitec.Common.ctlBytTextBoxEx txt_Address1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private Sugitec.Common.ctlBytTextBoxEx txt_initial;
        private System.Windows.Forms.Label label2;
        private Sugitec.Common.ctlBytTextBoxEx txt_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private Sugitec.Common.ucDataGridViewEx dgv;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button Cmd_End;
        private System.Windows.Forms.Label label7;
        private Sugitec.Common.ctlDateTimePickerEx dtp_birthday;
        private System.Windows.Forms.ComboBox cmb_belongs;
        private System.Windows.Forms.GroupBox grp_Sex;
        private System.Windows.Forms.RadioButton rd_male;
        private System.Windows.Forms.RadioButton rd_female;
        private System.Windows.Forms.Button btn_delete;
        private Sugitec.Common.ucNumTextBox　txt_ID;
        private Sugitec.Common.ucNumTextBox txt_zipcd;
        private Sugitec.Common.ucNumTextBox txt_TelNo;
        private Sugitec.Common.ucNumTextBox txt_mobileNo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_GROUPCD;
        private System.Windows.Forms.Label label11;
        private Common.ctlBytTextBoxEx txt_Address2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dgv_del;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_initial;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_birthday;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_sex;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_zip;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_TEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_mobileTEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_belongs;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_GROUPCD;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_Address1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_address2;
        private System.Windows.Forms.Button btncopy1;
        private System.Windows.Forms.Button btncopy2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}