﻿namespace Sugitec
{
    partial class frmInq100
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblnow9 = new System.Windows.Forms.Label();
            this.lblbefore9 = new System.Windows.Forms.Label();
            this.lblcomp9 = new System.Windows.Forms.Label();
            this.lblUpdown9 = new System.Windows.Forms.Label();
            this.lblnow8 = new System.Windows.Forms.Label();
            this.lblbefore8 = new System.Windows.Forms.Label();
            this.lblcomp8 = new System.Windows.Forms.Label();
            this.lblUpdown8 = new System.Windows.Forms.Label();
            this.lblnow7 = new System.Windows.Forms.Label();
            this.lblbefore7 = new System.Windows.Forms.Label();
            this.lblcomp7 = new System.Windows.Forms.Label();
            this.lblUpdown7 = new System.Windows.Forms.Label();
            this.lblnow6 = new System.Windows.Forms.Label();
            this.lblbefore6 = new System.Windows.Forms.Label();
            this.lblcomp6 = new System.Windows.Forms.Label();
            this.lblUpdown6 = new System.Windows.Forms.Label();
            this.lblnow5 = new System.Windows.Forms.Label();
            this.lblbefore5 = new System.Windows.Forms.Label();
            this.lblcomp5 = new System.Windows.Forms.Label();
            this.lblUpdown5 = new System.Windows.Forms.Label();
            this.lblnow4 = new System.Windows.Forms.Label();
            this.lblbefore4 = new System.Windows.Forms.Label();
            this.lblcomp4 = new System.Windows.Forms.Label();
            this.lblUpdown4 = new System.Windows.Forms.Label();
            this.lblDate4 = new System.Windows.Forms.Label();
            this.lblcomp1 = new System.Windows.Forms.Label();
            this.lblbefore1 = new System.Windows.Forms.Label();
            this.lblnow1 = new System.Windows.Forms.Label();
            this.lblnow3 = new System.Windows.Forms.Label();
            this.lblcomp3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblbefore3 = new System.Windows.Forms.Label();
            this.lblbefore2 = new System.Windows.Forms.Label();
            this.lblcomp2 = new System.Windows.Forms.Label();
            this.lblUpdown3 = new System.Windows.Forms.Label();
            this.lblDate3 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblUpdown2 = new System.Windows.Forms.Label();
            this.lblDate2 = new System.Windows.Forms.Label();
            this.lblDate1 = new System.Windows.Forms.Label();
            this.lblnow2 = new System.Windows.Forms.Label();
            this.lblDate5 = new System.Windows.Forms.Label();
            this.lblDate6 = new System.Windows.Forms.Label();
            this.lblDate7 = new System.Windows.Forms.Label();
            this.lblDate8 = new System.Windows.Forms.Label();
            this.lblDate9 = new System.Windows.Forms.Label();
            this.lblUpdown1 = new System.Windows.Forms.Label();
            this.lblTaxAmount = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblnowAmount = new System.Windows.Forms.Label();
            this.lblbeforeAmount = new System.Windows.Forms.Label();
            this.lblDate10 = new System.Windows.Forms.Label();
            this.lblDate11 = new System.Windows.Forms.Label();
            this.lblnow10 = new System.Windows.Forms.Label();
            this.lblbefore10 = new System.Windows.Forms.Label();
            this.lblnow11 = new System.Windows.Forms.Label();
            this.lblnow12 = new System.Windows.Forms.Label();
            this.lblbefore11 = new System.Windows.Forms.Label();
            this.lblbefore12 = new System.Windows.Forms.Label();
            this.lblcomp10 = new System.Windows.Forms.Label();
            this.lblUpdown10 = new System.Windows.Forms.Label();
            this.lblcomp11 = new System.Windows.Forms.Label();
            this.lblUpdown11 = new System.Windows.Forms.Label();
            this.lblDate12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblcomp12 = new System.Windows.Forms.Label();
            this.lblUpdown12 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.btn_Disp = new System.Windows.Forms.Button();
            this.numYear = new Sugitec.Common.ucNumTextBox();
            this.btn_end = new System.Windows.Forms.Button();
            this.btn_Excel = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_PDF = new System.Windows.Forms.Button();
            this.btn_Printer = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.lblnow9, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore9, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp9, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown9, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblnow8, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore8, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp8, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown8, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblnow7, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore7, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp7, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown7, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblnow6, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore6, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp6, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown6, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblnow5, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore5, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp5, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown5, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblnow4, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore4, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp4, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown4, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblDate4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp1, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblnow1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblnow3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp3, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label9, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label8, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp2, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown3, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblDate3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown2, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblDate2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblDate1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblnow2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblDate5, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblDate6, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblDate7, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblDate8, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblDate9, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown1, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblTaxAmount, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.lblTax, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.lblnowAmount, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.lblbeforeAmount, 2, 13);
            this.tableLayoutPanel1.Controls.Add(this.lblDate10, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.lblDate11, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.lblnow10, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore10, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.lblnow11, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.lblnow12, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore11, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.lblbefore12, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp10, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown10, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp11, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown11, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.lblDate12, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 15);
            this.tableLayoutPanel1.Controls.Add(this.lblcomp12, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.lblUpdown12, 4, 12);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(14, 94);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 16;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.250351F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.248477F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.248477F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.248477F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(740, 482);
            this.tableLayoutPanel1.TabIndex = 18;
            // 
            // lblnow9
            // 
            this.lblnow9.BackColor = System.Drawing.Color.White;
            this.lblnow9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow9.Location = new System.Drawing.Point(148, 270);
            this.lblnow9.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow9.Name = "lblnow9";
            this.lblnow9.Size = new System.Drawing.Size(148, 30);
            this.lblnow9.TabIndex = 56;
            this.lblnow9.Text = "0";
            this.lblnow9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore9
            // 
            this.lblbefore9.BackColor = System.Drawing.Color.White;
            this.lblbefore9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore9.Location = new System.Drawing.Point(296, 270);
            this.lblbefore9.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore9.Name = "lblbefore9";
            this.lblbefore9.Size = new System.Drawing.Size(148, 30);
            this.lblbefore9.TabIndex = 54;
            this.lblbefore9.Text = "0";
            this.lblbefore9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp9
            // 
            this.lblcomp9.BackColor = System.Drawing.Color.White;
            this.lblcomp9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp9.Location = new System.Drawing.Point(444, 270);
            this.lblcomp9.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp9.Name = "lblcomp9";
            this.lblcomp9.Size = new System.Drawing.Size(148, 30);
            this.lblcomp9.TabIndex = 53;
            this.lblcomp9.Text = "0";
            this.lblcomp9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown9
            // 
            this.lblUpdown9.BackColor = System.Drawing.Color.White;
            this.lblUpdown9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown9.Location = new System.Drawing.Point(592, 270);
            this.lblUpdown9.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown9.Name = "lblUpdown9";
            this.lblUpdown9.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown9.TabIndex = 55;
            this.lblUpdown9.Text = "0";
            this.lblUpdown9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow8
            // 
            this.lblnow8.BackColor = System.Drawing.Color.White;
            this.lblnow8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow8.Location = new System.Drawing.Point(148, 240);
            this.lblnow8.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow8.Name = "lblnow8";
            this.lblnow8.Size = new System.Drawing.Size(148, 30);
            this.lblnow8.TabIndex = 48;
            this.lblnow8.Text = "0";
            this.lblnow8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore8
            // 
            this.lblbefore8.BackColor = System.Drawing.Color.White;
            this.lblbefore8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore8.Location = new System.Drawing.Point(296, 240);
            this.lblbefore8.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore8.Name = "lblbefore8";
            this.lblbefore8.Size = new System.Drawing.Size(148, 30);
            this.lblbefore8.TabIndex = 50;
            this.lblbefore8.Text = "0";
            this.lblbefore8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp8
            // 
            this.lblcomp8.BackColor = System.Drawing.Color.White;
            this.lblcomp8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp8.Location = new System.Drawing.Point(444, 240);
            this.lblcomp8.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp8.Name = "lblcomp8";
            this.lblcomp8.Size = new System.Drawing.Size(148, 30);
            this.lblcomp8.TabIndex = 49;
            this.lblcomp8.Text = "0";
            this.lblcomp8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown8
            // 
            this.lblUpdown8.BackColor = System.Drawing.Color.White;
            this.lblUpdown8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown8.Location = new System.Drawing.Point(592, 240);
            this.lblUpdown8.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown8.Name = "lblUpdown8";
            this.lblUpdown8.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown8.TabIndex = 51;
            this.lblUpdown8.Text = "0";
            this.lblUpdown8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow7
            // 
            this.lblnow7.BackColor = System.Drawing.Color.White;
            this.lblnow7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow7.Location = new System.Drawing.Point(148, 210);
            this.lblnow7.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow7.Name = "lblnow7";
            this.lblnow7.Size = new System.Drawing.Size(148, 30);
            this.lblnow7.TabIndex = 44;
            this.lblnow7.Text = "0";
            this.lblnow7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore7
            // 
            this.lblbefore7.BackColor = System.Drawing.Color.White;
            this.lblbefore7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore7.Location = new System.Drawing.Point(296, 210);
            this.lblbefore7.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore7.Name = "lblbefore7";
            this.lblbefore7.Size = new System.Drawing.Size(148, 30);
            this.lblbefore7.TabIndex = 46;
            this.lblbefore7.Text = "0";
            this.lblbefore7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp7
            // 
            this.lblcomp7.BackColor = System.Drawing.Color.White;
            this.lblcomp7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp7.Location = new System.Drawing.Point(444, 210);
            this.lblcomp7.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp7.Name = "lblcomp7";
            this.lblcomp7.Size = new System.Drawing.Size(148, 30);
            this.lblcomp7.TabIndex = 45;
            this.lblcomp7.Text = "0";
            this.lblcomp7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown7
            // 
            this.lblUpdown7.BackColor = System.Drawing.Color.White;
            this.lblUpdown7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown7.Location = new System.Drawing.Point(592, 210);
            this.lblUpdown7.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown7.Name = "lblUpdown7";
            this.lblUpdown7.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown7.TabIndex = 47;
            this.lblUpdown7.Text = "0";
            this.lblUpdown7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow6
            // 
            this.lblnow6.BackColor = System.Drawing.Color.White;
            this.lblnow6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow6.Location = new System.Drawing.Point(148, 180);
            this.lblnow6.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow6.Name = "lblnow6";
            this.lblnow6.Size = new System.Drawing.Size(148, 30);
            this.lblnow6.TabIndex = 40;
            this.lblnow6.Text = "0";
            this.lblnow6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore6
            // 
            this.lblbefore6.BackColor = System.Drawing.Color.White;
            this.lblbefore6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore6.Location = new System.Drawing.Point(296, 180);
            this.lblbefore6.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore6.Name = "lblbefore6";
            this.lblbefore6.Size = new System.Drawing.Size(148, 30);
            this.lblbefore6.TabIndex = 42;
            this.lblbefore6.Text = "0";
            this.lblbefore6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp6
            // 
            this.lblcomp6.BackColor = System.Drawing.Color.White;
            this.lblcomp6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp6.Location = new System.Drawing.Point(444, 180);
            this.lblcomp6.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp6.Name = "lblcomp6";
            this.lblcomp6.Size = new System.Drawing.Size(148, 30);
            this.lblcomp6.TabIndex = 41;
            this.lblcomp6.Text = "0";
            this.lblcomp6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown6
            // 
            this.lblUpdown6.BackColor = System.Drawing.Color.White;
            this.lblUpdown6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown6.Location = new System.Drawing.Point(592, 180);
            this.lblUpdown6.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown6.Name = "lblUpdown6";
            this.lblUpdown6.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown6.TabIndex = 43;
            this.lblUpdown6.Text = "0";
            this.lblUpdown6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow5
            // 
            this.lblnow5.BackColor = System.Drawing.Color.White;
            this.lblnow5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow5.Location = new System.Drawing.Point(148, 150);
            this.lblnow5.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow5.Name = "lblnow5";
            this.lblnow5.Size = new System.Drawing.Size(148, 30);
            this.lblnow5.TabIndex = 36;
            this.lblnow5.Text = "0";
            this.lblnow5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore5
            // 
            this.lblbefore5.BackColor = System.Drawing.Color.White;
            this.lblbefore5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore5.Location = new System.Drawing.Point(296, 150);
            this.lblbefore5.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore5.Name = "lblbefore5";
            this.lblbefore5.Size = new System.Drawing.Size(148, 30);
            this.lblbefore5.TabIndex = 38;
            this.lblbefore5.Text = "0";
            this.lblbefore5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp5
            // 
            this.lblcomp5.BackColor = System.Drawing.Color.White;
            this.lblcomp5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp5.Location = new System.Drawing.Point(444, 150);
            this.lblcomp5.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp5.Name = "lblcomp5";
            this.lblcomp5.Size = new System.Drawing.Size(148, 30);
            this.lblcomp5.TabIndex = 37;
            this.lblcomp5.Text = "0";
            this.lblcomp5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown5
            // 
            this.lblUpdown5.BackColor = System.Drawing.Color.White;
            this.lblUpdown5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown5.Location = new System.Drawing.Point(592, 150);
            this.lblUpdown5.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown5.Name = "lblUpdown5";
            this.lblUpdown5.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown5.TabIndex = 39;
            this.lblUpdown5.Text = "0";
            this.lblUpdown5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow4
            // 
            this.lblnow4.BackColor = System.Drawing.Color.White;
            this.lblnow4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow4.Location = new System.Drawing.Point(148, 120);
            this.lblnow4.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow4.Name = "lblnow4";
            this.lblnow4.Size = new System.Drawing.Size(148, 30);
            this.lblnow4.TabIndex = 32;
            this.lblnow4.Text = "0";
            this.lblnow4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore4
            // 
            this.lblbefore4.BackColor = System.Drawing.Color.White;
            this.lblbefore4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore4.Location = new System.Drawing.Point(296, 120);
            this.lblbefore4.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore4.Name = "lblbefore4";
            this.lblbefore4.Size = new System.Drawing.Size(148, 30);
            this.lblbefore4.TabIndex = 34;
            this.lblbefore4.Text = "0";
            this.lblbefore4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp4
            // 
            this.lblcomp4.BackColor = System.Drawing.Color.White;
            this.lblcomp4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp4.Location = new System.Drawing.Point(444, 120);
            this.lblcomp4.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp4.Name = "lblcomp4";
            this.lblcomp4.Size = new System.Drawing.Size(148, 30);
            this.lblcomp4.TabIndex = 33;
            this.lblcomp4.Text = "0";
            this.lblcomp4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown4
            // 
            this.lblUpdown4.BackColor = System.Drawing.Color.White;
            this.lblUpdown4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown4.Location = new System.Drawing.Point(592, 120);
            this.lblUpdown4.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown4.Name = "lblUpdown4";
            this.lblUpdown4.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown4.TabIndex = 35;
            this.lblUpdown4.Text = "0";
            this.lblUpdown4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDate4
            // 
            this.lblDate4.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate4.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate4.Location = new System.Drawing.Point(0, 120);
            this.lblDate4.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate4.Name = "lblDate4";
            this.lblDate4.Size = new System.Drawing.Size(148, 30);
            this.lblDate4.TabIndex = 19;
            this.lblDate4.Text = "平成29年6月";
            this.lblDate4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblcomp1
            // 
            this.lblcomp1.BackColor = System.Drawing.Color.White;
            this.lblcomp1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp1.Location = new System.Drawing.Point(444, 30);
            this.lblcomp1.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp1.Name = "lblcomp1";
            this.lblcomp1.Size = new System.Drawing.Size(148, 30);
            this.lblcomp1.TabIndex = 7;
            this.lblcomp1.Text = "0";
            this.lblcomp1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore1
            // 
            this.lblbefore1.BackColor = System.Drawing.Color.White;
            this.lblbefore1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore1.Location = new System.Drawing.Point(296, 30);
            this.lblbefore1.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore1.Name = "lblbefore1";
            this.lblbefore1.Size = new System.Drawing.Size(148, 30);
            this.lblbefore1.TabIndex = 6;
            this.lblbefore1.Text = "0";
            this.lblbefore1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow1
            // 
            this.lblnow1.BackColor = System.Drawing.Color.White;
            this.lblnow1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow1.Location = new System.Drawing.Point(148, 30);
            this.lblnow1.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow1.Name = "lblnow1";
            this.lblnow1.Size = new System.Drawing.Size(148, 30);
            this.lblnow1.TabIndex = 5;
            this.lblnow1.Text = "0";
            this.lblnow1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow3
            // 
            this.lblnow3.BackColor = System.Drawing.Color.White;
            this.lblnow3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow3.Location = new System.Drawing.Point(296, 90);
            this.lblnow3.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow3.Name = "lblnow3";
            this.lblnow3.Size = new System.Drawing.Size(148, 30);
            this.lblnow3.TabIndex = 13;
            this.lblnow3.Text = "0";
            this.lblnow3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp3
            // 
            this.lblcomp3.BackColor = System.Drawing.Color.White;
            this.lblcomp3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp3.Location = new System.Drawing.Point(444, 90);
            this.lblcomp3.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp3.Name = "lblcomp3";
            this.lblcomp3.Size = new System.Drawing.Size(148, 30);
            this.lblcomp3.TabIndex = 15;
            this.lblcomp3.Text = "0";
            this.lblcomp3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.GreenYellow;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label9.Location = new System.Drawing.Point(296, 0);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(148, 30);
            this.label9.TabIndex = 1;
            this.label9.Text = "前年度売上";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.GreenYellow;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label11.Location = new System.Drawing.Point(444, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(148, 30);
            this.label11.TabIndex = 2;
            this.label11.Text = "前年比";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.GreenYellow;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label18.Location = new System.Drawing.Point(592, 0);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(148, 30);
            this.label18.TabIndex = 3;
            this.label18.Text = "増減";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.BackColor = System.Drawing.Color.GreenYellow;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label8.Location = new System.Drawing.Point(148, 0);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(148, 30);
            this.label8.TabIndex = 0;
            this.label8.Text = "今年度売上";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblbefore3
            // 
            this.lblbefore3.BackColor = System.Drawing.Color.White;
            this.lblbefore3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore3.Location = new System.Drawing.Point(148, 90);
            this.lblbefore3.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore3.Name = "lblbefore3";
            this.lblbefore3.Size = new System.Drawing.Size(148, 30);
            this.lblbefore3.TabIndex = 14;
            this.lblbefore3.Text = "0";
            this.lblbefore3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore2
            // 
            this.lblbefore2.BackColor = System.Drawing.Color.White;
            this.lblbefore2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore2.Location = new System.Drawing.Point(296, 60);
            this.lblbefore2.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore2.Name = "lblbefore2";
            this.lblbefore2.Size = new System.Drawing.Size(148, 30);
            this.lblbefore2.TabIndex = 10;
            this.lblbefore2.Text = "0";
            this.lblbefore2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp2
            // 
            this.lblcomp2.BackColor = System.Drawing.Color.White;
            this.lblcomp2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp2.Location = new System.Drawing.Point(444, 60);
            this.lblcomp2.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp2.Name = "lblcomp2";
            this.lblcomp2.Size = new System.Drawing.Size(148, 30);
            this.lblcomp2.TabIndex = 11;
            this.lblcomp2.Text = "0";
            this.lblcomp2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown3
            // 
            this.lblUpdown3.BackColor = System.Drawing.Color.White;
            this.lblUpdown3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown3.Location = new System.Drawing.Point(592, 90);
            this.lblUpdown3.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown3.Name = "lblUpdown3";
            this.lblUpdown3.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown3.TabIndex = 16;
            this.lblUpdown3.Text = "0";
            this.lblUpdown3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDate3
            // 
            this.lblDate3.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate3.Location = new System.Drawing.Point(0, 90);
            this.lblDate3.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate3.Name = "lblDate3";
            this.lblDate3.Size = new System.Drawing.Size(148, 30);
            this.lblDate3.TabIndex = 12;
            this.lblDate3.Text = "平成29年5月";
            this.lblDate3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.GreenYellow;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(148, 30);
            this.label19.TabIndex = 17;
            // 
            // lblUpdown2
            // 
            this.lblUpdown2.BackColor = System.Drawing.Color.White;
            this.lblUpdown2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown2.Location = new System.Drawing.Point(592, 60);
            this.lblUpdown2.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown2.Name = "lblUpdown2";
            this.lblUpdown2.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown2.TabIndex = 19;
            this.lblUpdown2.Text = "0";
            this.lblUpdown2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDate2
            // 
            this.lblDate2.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate2.Location = new System.Drawing.Point(0, 60);
            this.lblDate2.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate2.Name = "lblDate2";
            this.lblDate2.Size = new System.Drawing.Size(148, 30);
            this.lblDate2.TabIndex = 8;
            this.lblDate2.Text = "平成29年4月";
            this.lblDate2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate1
            // 
            this.lblDate1.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate1.Location = new System.Drawing.Point(0, 30);
            this.lblDate1.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate1.Name = "lblDate1";
            this.lblDate1.Size = new System.Drawing.Size(148, 30);
            this.lblDate1.TabIndex = 4;
            this.lblDate1.Text = "平成29年3月";
            this.lblDate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblnow2
            // 
            this.lblnow2.BackColor = System.Drawing.Color.White;
            this.lblnow2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow2.Location = new System.Drawing.Point(148, 60);
            this.lblnow2.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow2.Name = "lblnow2";
            this.lblnow2.Size = new System.Drawing.Size(148, 30);
            this.lblnow2.TabIndex = 9;
            this.lblnow2.Text = "0";
            this.lblnow2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDate5
            // 
            this.lblDate5.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate5.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate5.Location = new System.Drawing.Point(0, 150);
            this.lblDate5.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate5.Name = "lblDate5";
            this.lblDate5.Size = new System.Drawing.Size(148, 30);
            this.lblDate5.TabIndex = 21;
            this.lblDate5.Text = "平成29年7月";
            this.lblDate5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate6
            // 
            this.lblDate6.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate6.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate6.Location = new System.Drawing.Point(0, 180);
            this.lblDate6.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate6.Name = "lblDate6";
            this.lblDate6.Size = new System.Drawing.Size(148, 30);
            this.lblDate6.TabIndex = 22;
            this.lblDate6.Text = "平成29年8月";
            this.lblDate6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate7
            // 
            this.lblDate7.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate7.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate7.Location = new System.Drawing.Point(0, 210);
            this.lblDate7.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate7.Name = "lblDate7";
            this.lblDate7.Size = new System.Drawing.Size(148, 30);
            this.lblDate7.TabIndex = 23;
            this.lblDate7.Text = "平成29年9月";
            this.lblDate7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate8
            // 
            this.lblDate8.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate8.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate8.Location = new System.Drawing.Point(0, 240);
            this.lblDate8.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate8.Name = "lblDate8";
            this.lblDate8.Size = new System.Drawing.Size(148, 30);
            this.lblDate8.TabIndex = 24;
            this.lblDate8.Text = "平成29年10月";
            this.lblDate8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate9
            // 
            this.lblDate9.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate9.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate9.Location = new System.Drawing.Point(0, 270);
            this.lblDate9.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate9.Name = "lblDate9";
            this.lblDate9.Size = new System.Drawing.Size(148, 30);
            this.lblDate9.TabIndex = 25;
            this.lblDate9.Text = "平成29年11月";
            this.lblDate9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUpdown1
            // 
            this.lblUpdown1.BackColor = System.Drawing.Color.White;
            this.lblUpdown1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown1.Location = new System.Drawing.Point(592, 30);
            this.lblUpdown1.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown1.Name = "lblUpdown1";
            this.lblUpdown1.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown1.TabIndex = 18;
            this.lblUpdown1.Text = "0";
            this.lblUpdown1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTaxAmount
            // 
            this.lblTaxAmount.BackColor = System.Drawing.Color.White;
            this.lblTaxAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTaxAmount.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTaxAmount.Location = new System.Drawing.Point(148, 450);
            this.lblTaxAmount.Margin = new System.Windows.Forms.Padding(0);
            this.lblTaxAmount.Name = "lblTaxAmount";
            this.lblTaxAmount.Size = new System.Drawing.Size(148, 31);
            this.lblTaxAmount.TabIndex = 60;
            this.lblTaxAmount.Text = "0";
            this.lblTaxAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.GreenYellow;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label17.Location = new System.Drawing.Point(0, 420);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(148, 30);
            this.label17.TabIndex = 31;
            this.label17.Text = "消費税";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTax
            // 
            this.lblTax.BackColor = System.Drawing.Color.White;
            this.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTax.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTax.Location = new System.Drawing.Point(148, 420);
            this.lblTax.Margin = new System.Windows.Forms.Padding(0);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(148, 30);
            this.lblTax.TabIndex = 59;
            this.lblTax.Text = "0";
            this.lblTax.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.GreenYellow;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label15.Location = new System.Drawing.Point(0, 390);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(148, 30);
            this.label15.TabIndex = 29;
            this.label15.Text = "消費税抜き";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblnowAmount
            // 
            this.lblnowAmount.BackColor = System.Drawing.Color.White;
            this.lblnowAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnowAmount.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnowAmount.Location = new System.Drawing.Point(148, 390);
            this.lblnowAmount.Margin = new System.Windows.Forms.Padding(0);
            this.lblnowAmount.Name = "lblnowAmount";
            this.lblnowAmount.Size = new System.Drawing.Size(148, 30);
            this.lblnowAmount.TabIndex = 57;
            this.lblnowAmount.Text = "0";
            this.lblnowAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbeforeAmount
            // 
            this.lblbeforeAmount.BackColor = System.Drawing.Color.White;
            this.lblbeforeAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbeforeAmount.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbeforeAmount.Location = new System.Drawing.Point(296, 390);
            this.lblbeforeAmount.Margin = new System.Windows.Forms.Padding(0);
            this.lblbeforeAmount.Name = "lblbeforeAmount";
            this.lblbeforeAmount.Size = new System.Drawing.Size(148, 30);
            this.lblbeforeAmount.TabIndex = 58;
            this.lblbeforeAmount.Text = "0";
            this.lblbeforeAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDate10
            // 
            this.lblDate10.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate10.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate10.Location = new System.Drawing.Point(0, 300);
            this.lblDate10.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate10.Name = "lblDate10";
            this.lblDate10.Size = new System.Drawing.Size(148, 30);
            this.lblDate10.TabIndex = 61;
            this.lblDate10.Text = "平成29年12月";
            this.lblDate10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate11
            // 
            this.lblDate11.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate11.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate11.Location = new System.Drawing.Point(0, 330);
            this.lblDate11.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate11.Name = "lblDate11";
            this.lblDate11.Size = new System.Drawing.Size(148, 30);
            this.lblDate11.TabIndex = 62;
            this.lblDate11.Text = "平成30年1月";
            this.lblDate11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblnow10
            // 
            this.lblnow10.BackColor = System.Drawing.Color.White;
            this.lblnow10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow10.Location = new System.Drawing.Point(148, 300);
            this.lblnow10.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow10.Name = "lblnow10";
            this.lblnow10.Size = new System.Drawing.Size(148, 30);
            this.lblnow10.TabIndex = 64;
            this.lblnow10.Text = "0";
            this.lblnow10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore10
            // 
            this.lblbefore10.BackColor = System.Drawing.Color.White;
            this.lblbefore10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore10.Location = new System.Drawing.Point(296, 300);
            this.lblbefore10.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore10.Name = "lblbefore10";
            this.lblbefore10.Size = new System.Drawing.Size(148, 30);
            this.lblbefore10.TabIndex = 65;
            this.lblbefore10.Text = "0";
            this.lblbefore10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow11
            // 
            this.lblnow11.BackColor = System.Drawing.Color.White;
            this.lblnow11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow11.Location = new System.Drawing.Point(148, 330);
            this.lblnow11.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow11.Name = "lblnow11";
            this.lblnow11.Size = new System.Drawing.Size(148, 30);
            this.lblnow11.TabIndex = 66;
            this.lblnow11.Text = "0";
            this.lblnow11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnow12
            // 
            this.lblnow12.BackColor = System.Drawing.Color.White;
            this.lblnow12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnow12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnow12.Location = new System.Drawing.Point(148, 360);
            this.lblnow12.Margin = new System.Windows.Forms.Padding(0);
            this.lblnow12.Name = "lblnow12";
            this.lblnow12.Size = new System.Drawing.Size(148, 30);
            this.lblnow12.TabIndex = 67;
            this.lblnow12.Text = "0";
            this.lblnow12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore11
            // 
            this.lblbefore11.BackColor = System.Drawing.Color.White;
            this.lblbefore11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore11.Location = new System.Drawing.Point(296, 330);
            this.lblbefore11.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore11.Name = "lblbefore11";
            this.lblbefore11.Size = new System.Drawing.Size(148, 30);
            this.lblbefore11.TabIndex = 68;
            this.lblbefore11.Text = "0";
            this.lblbefore11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblbefore12
            // 
            this.lblbefore12.BackColor = System.Drawing.Color.White;
            this.lblbefore12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbefore12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblbefore12.Location = new System.Drawing.Point(296, 360);
            this.lblbefore12.Margin = new System.Windows.Forms.Padding(0);
            this.lblbefore12.Name = "lblbefore12";
            this.lblbefore12.Size = new System.Drawing.Size(148, 30);
            this.lblbefore12.TabIndex = 69;
            this.lblbefore12.Text = "0";
            this.lblbefore12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp10
            // 
            this.lblcomp10.BackColor = System.Drawing.Color.White;
            this.lblcomp10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp10.Location = new System.Drawing.Point(444, 300);
            this.lblcomp10.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp10.Name = "lblcomp10";
            this.lblcomp10.Size = new System.Drawing.Size(148, 30);
            this.lblcomp10.TabIndex = 70;
            this.lblcomp10.Text = "0";
            this.lblcomp10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown10
            // 
            this.lblUpdown10.BackColor = System.Drawing.Color.White;
            this.lblUpdown10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown10.Location = new System.Drawing.Point(592, 300);
            this.lblUpdown10.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown10.Name = "lblUpdown10";
            this.lblUpdown10.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown10.TabIndex = 71;
            this.lblUpdown10.Text = "0";
            this.lblUpdown10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcomp11
            // 
            this.lblcomp11.BackColor = System.Drawing.Color.White;
            this.lblcomp11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp11.Location = new System.Drawing.Point(444, 330);
            this.lblcomp11.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp11.Name = "lblcomp11";
            this.lblcomp11.Size = new System.Drawing.Size(148, 30);
            this.lblcomp11.TabIndex = 72;
            this.lblcomp11.Text = "0";
            this.lblcomp11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown11
            // 
            this.lblUpdown11.BackColor = System.Drawing.Color.White;
            this.lblUpdown11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown11.Location = new System.Drawing.Point(592, 330);
            this.lblUpdown11.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown11.Name = "lblUpdown11";
            this.lblUpdown11.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown11.TabIndex = 73;
            this.lblUpdown11.Text = "0";
            this.lblUpdown11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDate12
            // 
            this.lblDate12.BackColor = System.Drawing.Color.GreenYellow;
            this.lblDate12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate12.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate12.Location = new System.Drawing.Point(0, 360);
            this.lblDate12.Margin = new System.Windows.Forms.Padding(0);
            this.lblDate12.Name = "lblDate12";
            this.lblDate12.Size = new System.Drawing.Size(148, 30);
            this.lblDate12.TabIndex = 63;
            this.lblDate12.Text = "平成30年2月";
            this.lblDate12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.GreenYellow;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label1.Location = new System.Drawing.Point(0, 450);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 31);
            this.label1.TabIndex = 20;
            this.label1.Text = "合計";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblcomp12
            // 
            this.lblcomp12.BackColor = System.Drawing.Color.White;
            this.lblcomp12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcomp12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcomp12.Location = new System.Drawing.Point(444, 360);
            this.lblcomp12.Margin = new System.Windows.Forms.Padding(0);
            this.lblcomp12.Name = "lblcomp12";
            this.lblcomp12.Size = new System.Drawing.Size(148, 30);
            this.lblcomp12.TabIndex = 74;
            this.lblcomp12.Text = "0";
            this.lblcomp12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdown12
            // 
            this.lblUpdown12.BackColor = System.Drawing.Color.White;
            this.lblUpdown12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdown12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUpdown12.Location = new System.Drawing.Point(592, 360);
            this.lblUpdown12.Margin = new System.Windows.Forms.Padding(0);
            this.lblUpdown12.Name = "lblUpdown12";
            this.lblUpdown12.Size = new System.Drawing.Size(148, 30);
            this.lblUpdown12.TabIndex = 75;
            this.lblUpdown12.Text = "0";
            this.lblUpdown12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(125, 60);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(35, 13);
            this.label48.TabIndex = 19;
            this.label48.Text = "年度";
            // 
            // btn_Disp
            // 
            this.btn_Disp.Location = new System.Drawing.Point(191, 48);
            this.btn_Disp.Name = "btn_Disp";
            this.btn_Disp.Size = new System.Drawing.Size(87, 37);
            this.btn_Disp.TabIndex = 0;
            this.btn_Disp.Text = "表示";
            this.btn_Disp.UseVisualStyleBackColor = true;
            this.btn_Disp.Click += new System.EventHandler(this.btn_Disp_Click);
            // 
            // numYear
            // 
            this.numYear.BackColor = System.Drawing.SystemColors.Window;
            this.numYear.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.numYear.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumeric;
            this.numYear.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numYear.ForeColor = System.Drawing.SystemColors.WindowText;
            this.numYear.Format = null;
            this.numYear.IllegalCharacter = ",.-";
            this.numYear.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.numYear.Location = new System.Drawing.Point(32, 56);
            this.numYear.MaxLength = 4;
            this.numYear.Name = "numYear";
            this.numYear.OldText = null;
            this.numYear.Size = new System.Drawing.Size(89, 20);
            this.numYear.TabIndex = 1;
            this.numYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numYear.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.None;
            // 
            // btn_end
            // 
            this.btn_end.Location = new System.Drawing.Point(668, 48);
            this.btn_end.Name = "btn_end";
            this.btn_end.Size = new System.Drawing.Size(87, 37);
            this.btn_end.TabIndex = 23;
            this.btn_end.Text = "終了";
            this.btn_end.UseVisualStyleBackColor = true;
            this.btn_end.Click += new System.EventHandler(this.btn_end_Click);
            // 
            // btn_Excel
            // 
            this.btn_Excel.Location = new System.Drawing.Point(296, 48);
            this.btn_Excel.Name = "btn_Excel";
            this.btn_Excel.Size = new System.Drawing.Size(87, 37);
            this.btn_Excel.TabIndex = 24;
            this.btn_Excel.Text = "Excel出力";
            this.btn_Excel.UseVisualStyleBackColor = true;
            this.btn_Excel.Click += new System.EventHandler(this.btn_output_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.Location = new System.Drawing.Point(575, 48);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(87, 37);
            this.btn_Clear.TabIndex = 25;
            this.btn_Clear.Text = "クリア";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_PDF
            // 
            this.btn_PDF.Location = new System.Drawing.Point(389, 48);
            this.btn_PDF.Name = "btn_PDF";
            this.btn_PDF.Size = new System.Drawing.Size(87, 37);
            this.btn_PDF.TabIndex = 26;
            this.btn_PDF.Text = "PDF出力";
            this.btn_PDF.UseVisualStyleBackColor = true;
            this.btn_PDF.Click += new System.EventHandler(this.btn_output_Click);
            // 
            // btn_Printer
            // 
            this.btn_Printer.Location = new System.Drawing.Point(482, 48);
            this.btn_Printer.Name = "btn_Printer";
            this.btn_Printer.Size = new System.Drawing.Size(87, 37);
            this.btn_Printer.TabIndex = 27;
            this.btn_Printer.Text = "印刷";
            this.btn_Printer.UseVisualStyleBackColor = true;
            this.btn_Printer.Click += new System.EventHandler(this.btn_output_Click);
            // 
            // frmInq100
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 617);
            this.Controls.Add(this.btn_Printer);
            this.Controls.Add(this.btn_PDF);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_Excel);
            this.Controls.Add(this.btn_end);
            this.Controls.Add(this.numYear);
            this.Controls.Add(this.btn_Disp);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmInq100";
            this.Text = "frmInq100";
            this.Controls.SetChildIndex(this.tableLayoutPanel1, 0);
            this.Controls.SetChildIndex(this.label48, 0);
            this.Controls.SetChildIndex(this.btn_Disp, 0);
            this.Controls.SetChildIndex(this.numYear, 0);
            this.Controls.SetChildIndex(this.btn_end, 0);
            this.Controls.SetChildIndex(this.btn_Excel, 0);
            this.Controls.SetChildIndex(this.btn_Clear, 0);
            this.Controls.SetChildIndex(this.btn_PDF, 0);
            this.Controls.SetChildIndex(this.btn_Printer, 0);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblcomp1;
        private System.Windows.Forms.Label lblbefore1;
        private System.Windows.Forms.Label lblnow1;
        private System.Windows.Forms.Label lblnow3;
        private System.Windows.Forms.Label lblcomp3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblbefore3;
        private System.Windows.Forms.Label lblnow2;
        private System.Windows.Forms.Label lblbefore2;
        private System.Windows.Forms.Label lblcomp2;
        private System.Windows.Forms.Label lblDate2;
        private System.Windows.Forms.Label lblDate1;
        private System.Windows.Forms.Label lblUpdown3;
        private System.Windows.Forms.Label lblDate3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblUpdown1;
        private System.Windows.Forms.Label lblUpdown2;
        private System.Windows.Forms.Label lblDate4;
        private System.Windows.Forms.Label lblDate5;
        private System.Windows.Forms.Label lblDate6;
        private System.Windows.Forms.Label lblDate7;
        private System.Windows.Forms.Label lblDate8;
        private System.Windows.Forms.Label lblDate9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblbeforeAmount;
        private System.Windows.Forms.Label lblnowAmount;
        private System.Windows.Forms.Label lblnow9;
        private System.Windows.Forms.Label lblbefore9;
        private System.Windows.Forms.Label lblcomp9;
        private System.Windows.Forms.Label lblUpdown9;
        private System.Windows.Forms.Label lblnow8;
        private System.Windows.Forms.Label lblbefore8;
        private System.Windows.Forms.Label lblcomp8;
        private System.Windows.Forms.Label lblUpdown8;
        private System.Windows.Forms.Label lblnow7;
        private System.Windows.Forms.Label lblbefore7;
        private System.Windows.Forms.Label lblcomp7;
        private System.Windows.Forms.Label lblUpdown7;
        private System.Windows.Forms.Label lblnow6;
        private System.Windows.Forms.Label lblbefore6;
        private System.Windows.Forms.Label lblcomp6;
        private System.Windows.Forms.Label lblUpdown6;
        private System.Windows.Forms.Label lblnow5;
        private System.Windows.Forms.Label lblbefore5;
        private System.Windows.Forms.Label lblcomp5;
        private System.Windows.Forms.Label lblUpdown5;
        private System.Windows.Forms.Label lblnow4;
        private System.Windows.Forms.Label lblbefore4;
        private System.Windows.Forms.Label lblcomp4;
        private System.Windows.Forms.Label lblUpdown4;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label lblTaxAmount;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button btn_Disp;
        private Common.ucNumTextBox numYear;
        private System.Windows.Forms.Label lblDate10;
        private System.Windows.Forms.Label lblDate11;
        private System.Windows.Forms.Label lblnow10;
        private System.Windows.Forms.Label lblbefore10;
        private System.Windows.Forms.Label lblnow11;
        private System.Windows.Forms.Label lblnow12;
        private System.Windows.Forms.Label lblbefore11;
        private System.Windows.Forms.Label lblbefore12;
        private System.Windows.Forms.Label lblcomp10;
        private System.Windows.Forms.Label lblUpdown10;
        private System.Windows.Forms.Label lblcomp11;
        private System.Windows.Forms.Label lblUpdown11;
        private System.Windows.Forms.Label lblDate12;
        private System.Windows.Forms.Label lblcomp12;
        private System.Windows.Forms.Label lblUpdown12;
        private System.Windows.Forms.Button btn_end;
        private System.Windows.Forms.Button btn_Excel;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_PDF;
        private System.Windows.Forms.Button btn_Printer;
    }
}