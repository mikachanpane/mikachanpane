﻿namespace Sugitec
{
    partial class frmMenu01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMnt100 = new System.Windows.Forms.Button();
            this.btnMnt110 = new System.Windows.Forms.Button();
            this.btnInq100 = new System.Windows.Forms.Button();
            this.btnOrd010 = new System.Windows.Forms.Button();
            this.btnOrd020 = new System.Windows.Forms.Button();
            this.btnRec020 = new System.Windows.Forms.Button();
            this.btnRec010 = new System.Windows.Forms.Button();
            this.btnSal020 = new System.Windows.Forms.Button();
            this.btnReq010 = new System.Windows.Forms.Button();
            this.btnReq020 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnDep010 = new System.Windows.Forms.Button();
            this.btnMnt130 = new System.Windows.Forms.Button();
            this.btnOth010 = new System.Windows.Forms.Button();
            this.btnMnt120 = new System.Windows.Forms.Button();
            this.btnDat010 = new System.Windows.Forms.Button();
            this.btnInq010 = new System.Windows.Forms.Button();
            this.btnMnt000 = new System.Windows.Forms.Button();
            this.btnMnt040 = new System.Windows.Forms.Button();
            this.btnMnt030 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMnt100
            // 
            this.btnMnt100.Location = new System.Drawing.Point(560, 4);
            this.btnMnt100.Name = "btnMnt100";
            this.btnMnt100.Size = new System.Drawing.Size(132, 31);
            this.btnMnt100.TabIndex = 2;
            this.btnMnt100.Text = "得意先";
            this.btnMnt100.UseVisualStyleBackColor = true;
            this.btnMnt100.Click += new System.EventHandler(this.btnMnt100_Click);
            // 
            // btnMnt110
            // 
            this.btnMnt110.Location = new System.Drawing.Point(560, 127);
            this.btnMnt110.Name = "btnMnt110";
            this.btnMnt110.Size = new System.Drawing.Size(132, 31);
            this.btnMnt110.TabIndex = 3;
            this.btnMnt110.Text = "技術者";
            this.btnMnt110.UseVisualStyleBackColor = true;
            this.btnMnt110.Click += new System.EventHandler(this.btnMnt110_Click);
            // 
            // btnInq100
            // 
            this.btnInq100.Location = new System.Drawing.Point(421, 4);
            this.btnInq100.Name = "btnInq100";
            this.btnInq100.Size = new System.Drawing.Size(132, 31);
            this.btnInq100.TabIndex = 15;
            this.btnInq100.Text = "年度売上帳";
            this.btnInq100.UseVisualStyleBackColor = true;
            this.btnInq100.Click += new System.EventHandler(this.btnInq100_Click);
            // 
            // btnOrd010
            // 
            this.btnOrd010.Location = new System.Drawing.Point(4, 4);
            this.btnOrd010.Name = "btnOrd010";
            this.btnOrd010.Size = new System.Drawing.Size(132, 31);
            this.btnOrd010.TabIndex = 22;
            this.btnOrd010.Text = "受注登録";
            this.btnOrd010.UseVisualStyleBackColor = true;
            this.btnOrd010.Click += new System.EventHandler(this.btnOrd010_Click);
            // 
            // btnOrd020
            // 
            this.btnOrd020.Location = new System.Drawing.Point(4, 45);
            this.btnOrd020.Name = "btnOrd020";
            this.btnOrd020.Size = new System.Drawing.Size(132, 31);
            this.btnOrd020.TabIndex = 23;
            this.btnOrd020.Text = "受注検索";
            this.btnOrd020.UseVisualStyleBackColor = true;
            this.btnOrd020.Click += new System.EventHandler(this.btnOrd020_Click);
            // 
            // btnRec020
            // 
            this.btnRec020.Location = new System.Drawing.Point(4, 168);
            this.btnRec020.Name = "btnRec020";
            this.btnRec020.Size = new System.Drawing.Size(132, 31);
            this.btnRec020.TabIndex = 24;
            this.btnRec020.Text = "入金検索";
            this.btnRec020.UseVisualStyleBackColor = true;
            this.btnRec020.Click += new System.EventHandler(this.btnRec020_Click);
            // 
            // btnRec010
            // 
            this.btnRec010.Location = new System.Drawing.Point(4, 127);
            this.btnRec010.Name = "btnRec010";
            this.btnRec010.Size = new System.Drawing.Size(132, 31);
            this.btnRec010.TabIndex = 25;
            this.btnRec010.Text = "入金登録";
            this.btnRec010.UseVisualStyleBackColor = true;
            this.btnRec010.Click += new System.EventHandler(this.btnRec010_Click);
            // 
            // btnSal020
            // 
            this.btnSal020.Location = new System.Drawing.Point(143, 4);
            this.btnSal020.Name = "btnSal020";
            this.btnSal020.Size = new System.Drawing.Size(132, 31);
            this.btnSal020.TabIndex = 26;
            this.btnSal020.Text = "売上登録";
            this.btnSal020.UseVisualStyleBackColor = true;
            this.btnSal020.Click += new System.EventHandler(this.btnSal020_Click);
            // 
            // btnReq010
            // 
            this.btnReq010.Location = new System.Drawing.Point(143, 86);
            this.btnReq010.Name = "btnReq010";
            this.btnReq010.Size = new System.Drawing.Size(132, 31);
            this.btnReq010.TabIndex = 27;
            this.btnReq010.Text = "請求締め";
            this.btnReq010.UseVisualStyleBackColor = true;
            this.btnReq010.Click += new System.EventHandler(this.btnReq010_Click);
            // 
            // btnReq020
            // 
            this.btnReq020.Location = new System.Drawing.Point(143, 127);
            this.btnReq020.Name = "btnReq020";
            this.btnReq020.Size = new System.Drawing.Size(132, 31);
            this.btnReq020.TabIndex = 28;
            this.btnReq020.Text = "請求書発行";
            this.btnReq020.UseVisualStyleBackColor = true;
            this.btnReq020.Click += new System.EventHandler(this.btnReq020_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Controls.Add(this.btnDep010, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.btnMnt130, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnOth010, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMnt120, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnDat010, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnInq010, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnOrd010, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnOrd020, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnSal020, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnMnt100, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnInq100, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnReq010, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnReq020, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnRec020, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnRec010, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnMnt000, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.btnMnt040, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.btnMnt030, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.btnMnt110, 4, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 51);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(838, 412);
            this.tableLayoutPanel1.TabIndex = 29;
            // 
            // btnDep010
            // 
            this.btnDep010.Location = new System.Drawing.Point(4, 250);
            this.btnDep010.Name = "btnDep010";
            this.btnDep010.Size = new System.Drawing.Size(132, 31);
            this.btnDep010.TabIndex = 30;
            this.btnDep010.Text = "回収検索";
            this.btnDep010.UseVisualStyleBackColor = true;
            this.btnDep010.Click += new System.EventHandler(this.btnDep010_Click);
            // 
            // btnMnt130
            // 
            this.btnMnt130.Location = new System.Drawing.Point(560, 45);
            this.btnMnt130.Name = "btnMnt130";
            this.btnMnt130.Size = new System.Drawing.Size(132, 31);
            this.btnMnt130.TabIndex = 30;
            this.btnMnt130.Text = "得意先担当者";
            this.btnMnt130.UseVisualStyleBackColor = true;
            this.btnMnt130.Click += new System.EventHandler(this.btnMnt130_Click);
            // 
            // btnOth010
            // 
            this.btnOth010.Location = new System.Drawing.Point(699, 45);
            this.btnOth010.Name = "btnOth010";
            this.btnOth010.Size = new System.Drawing.Size(130, 30);
            this.btnOth010.TabIndex = 33;
            this.btnOth010.Text = "送付状発行";
            this.btnOth010.UseVisualStyleBackColor = true;
            this.btnOth010.Click += new System.EventHandler(this.btnOth010_Click);
            // 
            // btnMnt120
            // 
            this.btnMnt120.Location = new System.Drawing.Point(560, 86);
            this.btnMnt120.Name = "btnMnt120";
            this.btnMnt120.Size = new System.Drawing.Size(132, 31);
            this.btnMnt120.TabIndex = 30;
            this.btnMnt120.Text = "所属グループ";
            this.btnMnt120.UseVisualStyleBackColor = true;
            this.btnMnt120.Click += new System.EventHandler(this.btnMnt120_Click);
            // 
            // btnDat010
            // 
            this.btnDat010.Location = new System.Drawing.Point(699, 4);
            this.btnDat010.Name = "btnDat010";
            this.btnDat010.Size = new System.Drawing.Size(130, 30);
            this.btnDat010.TabIndex = 32;
            this.btnDat010.Text = "データ同期";
            this.btnDat010.UseVisualStyleBackColor = true;
            this.btnDat010.Click += new System.EventHandler(this.btnDat010_Click);
            // 
            // btnInq010
            // 
            this.btnInq010.Location = new System.Drawing.Point(282, 4);
            this.btnInq010.Name = "btnInq010";
            this.btnInq010.Size = new System.Drawing.Size(130, 30);
            this.btnInq010.TabIndex = 29;
            this.btnInq010.Text = "月度売上帳";
            this.btnInq010.UseVisualStyleBackColor = true;
            this.btnInq010.Click += new System.EventHandler(this.btnInq010_Click);
            // 
            // btnMnt000
            // 
            this.btnMnt000.Location = new System.Drawing.Point(699, 373);
            this.btnMnt000.Name = "btnMnt000";
            this.btnMnt000.Size = new System.Drawing.Size(130, 30);
            this.btnMnt000.TabIndex = 33;
            this.btnMnt000.Text = "設定";
            this.btnMnt000.UseVisualStyleBackColor = true;
            // 
            // btnMnt040
            // 
            this.btnMnt040.Location = new System.Drawing.Point(560, 250);
            this.btnMnt040.Name = "btnMnt040";
            this.btnMnt040.Size = new System.Drawing.Size(130, 30);
            this.btnMnt040.TabIndex = 31;
            this.btnMnt040.Text = "消費税";
            this.btnMnt040.UseVisualStyleBackColor = true;
            this.btnMnt040.Click += new System.EventHandler(this.btnMnt040_Click);
            // 
            // btnMnt030
            // 
            this.btnMnt030.Location = new System.Drawing.Point(560, 209);
            this.btnMnt030.Name = "btnMnt030";
            this.btnMnt030.Size = new System.Drawing.Size(130, 30);
            this.btnMnt030.TabIndex = 30;
            this.btnMnt030.Text = "コード区分";
            this.btnMnt030.UseVisualStyleBackColor = true;
            this.btnMnt030.Click += new System.EventHandler(this.btnMnt030_Click);
            // 
            // frmMenu01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 528);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmMenu01";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
            this.Text = "frmManu01";
            this.Controls.SetChildIndex(this.tableLayoutPanel1, 0);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMnt100;
        private System.Windows.Forms.Button btnMnt110;
        private System.Windows.Forms.Button btnInq100;
        private System.Windows.Forms.Button btnOrd010;
        private System.Windows.Forms.Button btnOrd020;
        private System.Windows.Forms.Button btnRec020;
        private System.Windows.Forms.Button btnRec010;
        private System.Windows.Forms.Button btnSal020;
        private System.Windows.Forms.Button btnReq010;
        private System.Windows.Forms.Button btnReq020;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnDat010;
        private System.Windows.Forms.Button btnInq010;
        private System.Windows.Forms.Button btnMnt030;
        private System.Windows.Forms.Button btnMnt040;
        private System.Windows.Forms.Button btnMnt000;
        private System.Windows.Forms.Button btnMnt120;
        private System.Windows.Forms.Button btnOth010;
        private System.Windows.Forms.Button btnMnt130;
        private System.Windows.Forms.Button btnDep010;
    }
}