﻿namespace Sugitec
{
    partial class frmOrd020
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Sugitec.Common.HeaderCell headerCell18 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell19 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell20 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell21 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell22 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell23 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell24 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell25 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell26 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell27 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell28 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell29 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell30 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell31 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell32 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell33 = new Sugitec.Common.HeaderCell();
            Sugitec.Common.HeaderCell headerCell34 = new Sugitec.Common.HeaderCell();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCusOrdNo = new Sugitec.Common.ucTextBoxEx();
            this.label4 = new System.Windows.Forms.Label();
            this.mtbSaleYmT = new Sugitec.Common.ucYMTextbox();
            this.mtbSaleYmF = new Sugitec.Common.ucYMTextbox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbCus = new System.Windows.Forms.ComboBox();
            this.rdoCus2 = new System.Windows.Forms.RadioButton();
            this.rdoCus1 = new System.Windows.Forms.RadioButton();
            this.txtCusT = new Sugitec.Common.ucNumTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCusF = new Sugitec.Common.ucNumTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbEng = new System.Windows.Forms.ComboBox();
            this.rdoEng2 = new System.Windows.Forms.RadioButton();
            this.rdoEng1 = new System.Windows.Forms.RadioButton();
            this.txtEngT = new Sugitec.Common.ucNumTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEngF = new Sugitec.Common.ucNumTextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtProjectNm = new Sugitec.Common.ucTextBoxEx();
            this.label13 = new System.Windows.Forms.Label();
            this.txtOrderNoTo = new Sugitec.Common.ucNumTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOrderNoFrom = new Sugitec.Common.ucNumTextBox();
            this.dgv_Result = new Sugitec.Common.ucDataGridViewEx();
            this.dgv_ordNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_ordYMD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdCusCd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdCus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_CusOrdNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_ordPrjnm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdContTyp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdEngId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdEngNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdActkbn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdStrYMD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdEndYMD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdUlimit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdOlimit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdBaseRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dvg_OrdOvRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_OrdSubRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnEnd = new System.Windows.Forms.Button();
            this.btnClr = new System.Windows.Forms.Button();
            this.btnContinue = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtCusOrdNo);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.mtbSaleYmT);
            this.panel1.Controls.Add(this.mtbSaleYmF);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtProjectNm);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.txtOrderNoTo);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtOrderNoFrom);
            this.panel1.Location = new System.Drawing.Point(12, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1067, 136);
            this.panel1.TabIndex = 0;
            // 
            // txtCusOrdNo
            // 
            this.txtCusOrdNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtCusOrdNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCusOrdNo.Location = new System.Drawing.Point(108, 76);
            this.txtCusOrdNo.MaxLength = 20;
            this.txtCusOrdNo.Name = "txtCusOrdNo";
            this.txtCusOrdNo.Size = new System.Drawing.Size(200, 20);
            this.txtCusOrdNo.TabIndex = 9;
            this.txtCusOrdNo.xCharacterType = Sugitec.Common.ucTextBoxEx.emCharacterType.OnlyAlphaNumericSymbol;
            this.txtCusOrdNo.xFormat = null;
            this.txtCusOrdNo.xIllegalCharacter = null;
            this.txtCusOrdNo.xOldText = null;
            this.txtCusOrdNo.xZeroPadding = Sugitec.Common.ucTextBoxEx.emPaddingType.None;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.GreenYellow;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(12, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "客先注文№";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbSaleYmT
            // 
            this.mtbSaleYmT.BackColor = System.Drawing.SystemColors.Window;
            this.mtbSaleYmT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mtbSaleYmT.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.mtbSaleYmT.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mtbSaleYmT.Location = new System.Drawing.Point(232, 45);
            this.mtbSaleYmT.Name = "mtbSaleYmT";
            this.mtbSaleYmT.OldValue = null;
            this.mtbSaleYmT.Size = new System.Drawing.Size(97, 20);
            this.mtbSaleYmT.TabIndex = 7;
            this.mtbSaleYmT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // mtbSaleYmF
            // 
            this.mtbSaleYmF.BackColor = System.Drawing.SystemColors.Window;
            this.mtbSaleYmF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mtbSaleYmF.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.mtbSaleYmF.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mtbSaleYmF.Location = new System.Drawing.Point(108, 45);
            this.mtbSaleYmF.Name = "mtbSaleYmF";
            this.mtbSaleYmF.OldValue = null;
            this.mtbSaleYmF.Size = new System.Drawing.Size(97, 20);
            this.mtbSaleYmF.TabIndex = 5;
            this.mtbSaleYmF.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(208, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 20);
            this.label9.TabIndex = 6;
            this.label9.Text = "～";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.cmbCus);
            this.groupBox3.Controls.Add(this.rdoCus2);
            this.groupBox3.Controls.Add(this.rdoCus1);
            this.groupBox3.Controls.Add(this.txtCusT);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtCusF);
            this.groupBox3.Location = new System.Drawing.Point(346, 11);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(252, 89);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "得意先";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.GreenYellow;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "得意先";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbCus
            // 
            this.cmbCus.FormattingEnabled = true;
            this.cmbCus.Location = new System.Drawing.Point(45, 28);
            this.cmbCus.Name = "cmbCus";
            this.cmbCus.Size = new System.Drawing.Size(199, 21);
            this.cmbCus.TabIndex = 1;
            // 
            // rdoCus2
            // 
            this.rdoCus2.AutoSize = true;
            this.rdoCus2.Location = new System.Drawing.Point(15, 61);
            this.rdoCus2.Name = "rdoCus2";
            this.rdoCus2.Size = new System.Drawing.Size(14, 13);
            this.rdoCus2.TabIndex = 2;
            this.rdoCus2.UseVisualStyleBackColor = true;
            // 
            // rdoCus1
            // 
            this.rdoCus1.AutoSize = true;
            this.rdoCus1.Checked = true;
            this.rdoCus1.Location = new System.Drawing.Point(15, 31);
            this.rdoCus1.Name = "rdoCus1";
            this.rdoCus1.Size = new System.Drawing.Size(14, 13);
            this.rdoCus1.TabIndex = 0;
            this.rdoCus1.TabStop = true;
            this.rdoCus1.UseVisualStyleBackColor = true;
            // 
            // txtCusT
            // 
            this.txtCusT.BackColor = System.Drawing.SystemColors.Window;
            this.txtCusT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtCusT.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
            this.txtCusT.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtCusT.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtCusT.Format = null;
            this.txtCusT.IllegalCharacter = null;
            this.txtCusT.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCusT.Location = new System.Drawing.Point(160, 58);
            this.txtCusT.MaxLength = 8;
            this.txtCusT.Name = "txtCusT";
            this.txtCusT.OldText = null;
            this.txtCusT.Size = new System.Drawing.Size(84, 20);
            this.txtCusT.TabIndex = 5;
            this.txtCusT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCusT.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(135, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "～";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCusF
            // 
            this.txtCusF.BackColor = System.Drawing.SystemColors.Window;
            this.txtCusF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtCusF.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
            this.txtCusF.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtCusF.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtCusF.Format = null;
            this.txtCusF.IllegalCharacter = null;
            this.txtCusF.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCusF.Location = new System.Drawing.Point(45, 58);
            this.txtCusF.MaxLength = 8;
            this.txtCusF.Name = "txtCusF";
            this.txtCusF.OldText = null;
            this.txtCusF.Size = new System.Drawing.Size(84, 20);
            this.txtCusF.TabIndex = 3;
            this.txtCusF.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCusF.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.cmbEng);
            this.groupBox2.Controls.Add(this.rdoEng2);
            this.groupBox2.Controls.Add(this.rdoEng1);
            this.groupBox2.Controls.Add(this.txtEngT);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtEngF);
            this.groupBox2.Location = new System.Drawing.Point(611, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(252, 89);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "技術者";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.GreenYellow;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "技術者";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbEng
            // 
            this.cmbEng.FormattingEnabled = true;
            this.cmbEng.Location = new System.Drawing.Point(45, 28);
            this.cmbEng.Name = "cmbEng";
            this.cmbEng.Size = new System.Drawing.Size(195, 21);
            this.cmbEng.TabIndex = 1;
            // 
            // rdoEng2
            // 
            this.rdoEng2.AutoSize = true;
            this.rdoEng2.Location = new System.Drawing.Point(15, 61);
            this.rdoEng2.Name = "rdoEng2";
            this.rdoEng2.Size = new System.Drawing.Size(14, 13);
            this.rdoEng2.TabIndex = 2;
            this.rdoEng2.UseVisualStyleBackColor = true;
            // 
            // rdoEng1
            // 
            this.rdoEng1.AutoSize = true;
            this.rdoEng1.Checked = true;
            this.rdoEng1.Location = new System.Drawing.Point(15, 31);
            this.rdoEng1.Name = "rdoEng1";
            this.rdoEng1.Size = new System.Drawing.Size(14, 13);
            this.rdoEng1.TabIndex = 0;
            this.rdoEng1.TabStop = true;
            this.rdoEng1.UseVisualStyleBackColor = true;
            // 
            // txtEngT
            // 
            this.txtEngT.BackColor = System.Drawing.SystemColors.Window;
            this.txtEngT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtEngT.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
            this.txtEngT.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtEngT.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtEngT.Format = null;
            this.txtEngT.IllegalCharacter = null;
            this.txtEngT.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtEngT.Location = new System.Drawing.Point(156, 58);
            this.txtEngT.MaxLength = 8;
            this.txtEngT.Name = "txtEngT";
            this.txtEngT.OldText = null;
            this.txtEngT.Size = new System.Drawing.Size(84, 20);
            this.txtEngT.TabIndex = 5;
            this.txtEngT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtEngT.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(135, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 20);
            this.label7.TabIndex = 4;
            this.label7.Text = "～";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtEngF
            // 
            this.txtEngF.BackColor = System.Drawing.SystemColors.Window;
            this.txtEngF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtEngF.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
            this.txtEngF.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtEngF.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtEngF.Format = null;
            this.txtEngF.IllegalCharacter = null;
            this.txtEngF.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtEngF.Location = new System.Drawing.Point(45, 58);
            this.txtEngF.MaxLength = 8;
            this.txtEngF.Name = "txtEngF";
            this.txtEngF.OldText = null;
            this.txtEngF.Size = new System.Drawing.Size(84, 20);
            this.txtEngF.TabIndex = 3;
            this.txtEngF.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtEngF.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(874, 88);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 43);
            this.btnSearch.TabIndex = 14;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.GreenYellow;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Location = new System.Drawing.Point(12, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "案件名";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtProjectNm
            // 
            this.txtProjectNm.BackColor = System.Drawing.SystemColors.Window;
            this.txtProjectNm.ImeMode = System.Windows.Forms.ImeMode.On;
            this.txtProjectNm.Location = new System.Drawing.Point(108, 107);
            this.txtProjectNm.MaxLength = 100;
            this.txtProjectNm.Name = "txtProjectNm";
            this.txtProjectNm.Size = new System.Drawing.Size(755, 20);
            this.txtProjectNm.TabIndex = 13;
            this.txtProjectNm.xCharacterType = Sugitec.Common.ucTextBoxEx.emCharacterType.None;
            this.txtProjectNm.xFormat = null;
            this.txtProjectNm.xIllegalCharacter = null;
            this.txtProjectNm.xMaxLengthByByte = true;
            this.txtProjectNm.xOldText = null;
            this.txtProjectNm.xZeroPadding = Sugitec.Common.ucTextBoxEx.emPaddingType.None;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.GreenYellow;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.Location = new System.Drawing.Point(12, 47);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 20);
            this.label13.TabIndex = 4;
            this.label13.Text = "開始年月";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOrderNoTo
            // 
            this.txtOrderNoTo.BackColor = System.Drawing.SystemColors.Window;
            this.txtOrderNoTo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtOrderNoTo.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
            this.txtOrderNoTo.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtOrderNoTo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtOrderNoTo.Format = null;
            this.txtOrderNoTo.IllegalCharacter = null;
            this.txtOrderNoTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtOrderNoTo.Location = new System.Drawing.Point(232, 13);
            this.txtOrderNoTo.MaxLength = 8;
            this.txtOrderNoTo.Name = "txtOrderNoTo";
            this.txtOrderNoTo.OldText = null;
            this.txtOrderNoTo.Size = new System.Drawing.Size(97, 20);
            this.txtOrderNoTo.TabIndex = 3;
            this.txtOrderNoTo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtOrderNoTo.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(208, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(20, 20);
            this.label16.TabIndex = 2;
            this.label16.Text = "～";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.GreenYellow;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(12, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "受注№";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOrderNoFrom
            // 
            this.txtOrderNoFrom.BackColor = System.Drawing.SystemColors.Window;
            this.txtOrderNoFrom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtOrderNoFrom.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
            this.txtOrderNoFrom.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtOrderNoFrom.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtOrderNoFrom.Format = null;
            this.txtOrderNoFrom.IllegalCharacter = null;
            this.txtOrderNoFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtOrderNoFrom.Location = new System.Drawing.Point(108, 14);
            this.txtOrderNoFrom.MaxLength = 8;
            this.txtOrderNoFrom.Name = "txtOrderNoFrom";
            this.txtOrderNoFrom.OldText = null;
            this.txtOrderNoFrom.Size = new System.Drawing.Size(97, 20);
            this.txtOrderNoFrom.TabIndex = 1;
            this.txtOrderNoFrom.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtOrderNoFrom.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
            // 
            // dgv_Result
            // 
            this.dgv_Result.AllowUserToAddRows = false;
            this.dgv_Result.AllowUserToDeleteRows = false;
            this.dgv_Result.AllowUserToResizeRows = false;
            this.dgv_Result.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_Result.ColumnHeaderBorderStyle = Sugitec.Common.ucDataGridViewEx.HeaderCellBorderStyle.SingleLine;
            this.dgv_Result.ColumnHeaderRowCount = 1;
            this.dgv_Result.ColumnHeaderRowHeight = 20;
            this.dgv_Result.ColumnHeadersHeight = 22;
            this.dgv_Result.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgv_ordNo,
            this.dgv_ordYMD,
            this.dgv_OrdCusCd,
            this.dgv_OrdCus,
            this.dgv_CusOrdNo,
            this.dgv_ordPrjnm,
            this.dgv_OrdContTyp,
            this.dgv_OrdEngId,
            this.dgv_OrdEngNm,
            this.dgv_OrdActkbn,
            this.dgv_OrdStrYMD,
            this.dgv_OrdEndYMD,
            this.dgv_OrdUlimit,
            this.dgv_OrdOlimit,
            this.dgv_OrdBaseRate,
            this.dvg_OrdOvRate,
            this.dgv_OrdSubRate});
            headerCell18.BackgroundColor = System.Drawing.Color.Empty;
            headerCell18.Column = 0;
            headerCell18.ColumnSpan = 1;
            headerCell18.ForeColor = System.Drawing.Color.Empty;
            headerCell18.Row = 0;
            headerCell18.RowSpan = 1;
            headerCell18.SortVisible = false;
            headerCell18.Text = "受注№";
            headerCell18.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell18.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell19.BackgroundColor = System.Drawing.Color.Empty;
            headerCell19.Column = 1;
            headerCell19.ColumnSpan = 1;
            headerCell19.ForeColor = System.Drawing.Color.Empty;
            headerCell19.Row = 0;
            headerCell19.RowSpan = 1;
            headerCell19.SortVisible = false;
            headerCell19.Text = "受注日";
            headerCell19.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell19.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell20.BackgroundColor = System.Drawing.Color.Empty;
            headerCell20.Column = 2;
            headerCell20.ColumnSpan = 1;
            headerCell20.ForeColor = System.Drawing.Color.Empty;
            headerCell20.Row = 0;
            headerCell20.RowSpan = 1;
            headerCell20.SortVisible = false;
            headerCell20.Text = "得意先コード";
            headerCell20.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.NotSet;
            headerCell20.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell21.BackgroundColor = System.Drawing.Color.Empty;
            headerCell21.Column = 3;
            headerCell21.ColumnSpan = 1;
            headerCell21.ForeColor = System.Drawing.Color.Empty;
            headerCell21.Row = 0;
            headerCell21.RowSpan = 1;
            headerCell21.SortVisible = false;
            headerCell21.Text = "得意先";
            headerCell21.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell21.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell22.BackgroundColor = System.Drawing.Color.Empty;
            headerCell22.Column = 4;
            headerCell22.ColumnSpan = 1;
            headerCell22.ForeColor = System.Drawing.Color.Empty;
            headerCell22.Row = 0;
            headerCell22.RowSpan = 1;
            headerCell22.SortVisible = false;
            headerCell22.Text = "客先注文№";
            headerCell22.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell22.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell23.BackgroundColor = System.Drawing.Color.Empty;
            headerCell23.Column = 5;
            headerCell23.ColumnSpan = 1;
            headerCell23.ForeColor = System.Drawing.Color.Empty;
            headerCell23.Row = 0;
            headerCell23.RowSpan = 1;
            headerCell23.SortVisible = false;
            headerCell23.Text = "案件名";
            headerCell23.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell23.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell24.BackgroundColor = System.Drawing.Color.Empty;
            headerCell24.Column = 6;
            headerCell24.ColumnSpan = 1;
            headerCell24.ForeColor = System.Drawing.Color.Empty;
            headerCell24.Row = 0;
            headerCell24.RowSpan = 1;
            headerCell24.SortVisible = false;
            headerCell24.Text = "契約形態";
            headerCell24.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell24.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell25.BackgroundColor = System.Drawing.Color.Empty;
            headerCell25.Column = 7;
            headerCell25.ColumnSpan = 1;
            headerCell25.ForeColor = System.Drawing.Color.Empty;
            headerCell25.Row = 0;
            headerCell25.RowSpan = 1;
            headerCell25.SortVisible = false;
            headerCell25.Text = "技術者ＩＤ";
            headerCell25.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.NotSet;
            headerCell25.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell26.BackgroundColor = System.Drawing.Color.Empty;
            headerCell26.Column = 8;
            headerCell26.ColumnSpan = 1;
            headerCell26.ForeColor = System.Drawing.Color.Empty;
            headerCell26.Row = 0;
            headerCell26.RowSpan = 1;
            headerCell26.SortVisible = false;
            headerCell26.Text = "技術者";
            headerCell26.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell26.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell27.BackgroundColor = System.Drawing.Color.Empty;
            headerCell27.Column = 9;
            headerCell27.ColumnSpan = 1;
            headerCell27.ForeColor = System.Drawing.Color.Empty;
            headerCell27.Row = 0;
            headerCell27.RowSpan = 1;
            headerCell27.SortVisible = false;
            headerCell27.Text = "精算区分";
            headerCell27.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            headerCell27.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell28.BackgroundColor = System.Drawing.Color.Empty;
            headerCell28.Column = 10;
            headerCell28.ColumnSpan = 1;
            headerCell28.ForeColor = System.Drawing.Color.Empty;
            headerCell28.Row = 0;
            headerCell28.RowSpan = 1;
            headerCell28.SortVisible = false;
            headerCell28.Text = "開始期間";
            headerCell28.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell28.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell29.BackgroundColor = System.Drawing.Color.Empty;
            headerCell29.Column = 11;
            headerCell29.ColumnSpan = 1;
            headerCell29.ForeColor = System.Drawing.Color.Empty;
            headerCell29.Row = 0;
            headerCell29.RowSpan = 1;
            headerCell29.SortVisible = false;
            headerCell29.Text = "終了期間";
            headerCell29.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell29.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell30.BackgroundColor = System.Drawing.Color.Empty;
            headerCell30.Column = 12;
            headerCell30.ColumnSpan = 1;
            headerCell30.ForeColor = System.Drawing.Color.Empty;
            headerCell30.Row = 0;
            headerCell30.RowSpan = 1;
            headerCell30.SortVisible = false;
            headerCell30.Text = "下限時間";
            headerCell30.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell30.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell31.BackgroundColor = System.Drawing.Color.Empty;
            headerCell31.Column = 13;
            headerCell31.ColumnSpan = 1;
            headerCell31.ForeColor = System.Drawing.Color.Empty;
            headerCell31.Row = 0;
            headerCell31.RowSpan = 1;
            headerCell31.SortVisible = false;
            headerCell31.Text = "上限時間";
            headerCell31.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell31.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell32.BackgroundColor = System.Drawing.Color.Empty;
            headerCell32.Column = 14;
            headerCell32.ColumnSpan = 1;
            headerCell32.ForeColor = System.Drawing.Color.Empty;
            headerCell32.Row = 0;
            headerCell32.RowSpan = 1;
            headerCell32.SortVisible = false;
            headerCell32.Text = "基本単価";
            headerCell32.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell32.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell33.BackgroundColor = System.Drawing.Color.Empty;
            headerCell33.Column = 15;
            headerCell33.ColumnSpan = 1;
            headerCell33.ForeColor = System.Drawing.Color.Empty;
            headerCell33.Row = 0;
            headerCell33.RowSpan = 1;
            headerCell33.SortVisible = false;
            headerCell33.Text = "超過単価";
            headerCell33.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell33.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            headerCell34.BackgroundColor = System.Drawing.Color.Empty;
            headerCell34.Column = 16;
            headerCell34.ColumnSpan = 1;
            headerCell34.ForeColor = System.Drawing.Color.Empty;
            headerCell34.Row = 0;
            headerCell34.RowSpan = 1;
            headerCell34.SortVisible = false;
            headerCell34.Text = "控除単価";
            headerCell34.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            headerCell34.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
            this.dgv_Result.HeaderCells.Add(headerCell18);
            this.dgv_Result.HeaderCells.Add(headerCell19);
            this.dgv_Result.HeaderCells.Add(headerCell20);
            this.dgv_Result.HeaderCells.Add(headerCell21);
            this.dgv_Result.HeaderCells.Add(headerCell22);
            this.dgv_Result.HeaderCells.Add(headerCell23);
            this.dgv_Result.HeaderCells.Add(headerCell24);
            this.dgv_Result.HeaderCells.Add(headerCell25);
            this.dgv_Result.HeaderCells.Add(headerCell26);
            this.dgv_Result.HeaderCells.Add(headerCell27);
            this.dgv_Result.HeaderCells.Add(headerCell28);
            this.dgv_Result.HeaderCells.Add(headerCell29);
            this.dgv_Result.HeaderCells.Add(headerCell30);
            this.dgv_Result.HeaderCells.Add(headerCell31);
            this.dgv_Result.HeaderCells.Add(headerCell32);
            this.dgv_Result.HeaderCells.Add(headerCell33);
            this.dgv_Result.HeaderCells.Add(headerCell34);
            this.dgv_Result.Location = new System.Drawing.Point(12, 194);
            this.dgv_Result.Name = "dgv_Result";
            this.dgv_Result.RowHeadersVisible = false;
            this.dgv_Result.RowTemplate.Height = 21;
            this.dgv_Result.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Result.Size = new System.Drawing.Size(1067, 314);
            this.dgv_Result.TabIndex = 1;
            // 
            // dgv_ordNo
            // 
            this.dgv_ordNo.HeaderText = "受注№";
            this.dgv_ordNo.Name = "dgv_ordNo";
            // 
            // dgv_ordYMD
            // 
            this.dgv_ordYMD.HeaderText = "受注日";
            this.dgv_ordYMD.Name = "dgv_ordYMD";
            // 
            // dgv_OrdCusCd
            // 
            this.dgv_OrdCusCd.HeaderText = "得意先コード";
            this.dgv_OrdCusCd.Name = "dgv_OrdCusCd";
            this.dgv_OrdCusCd.Visible = false;
            // 
            // dgv_OrdCus
            // 
            this.dgv_OrdCus.HeaderText = "得意先";
            this.dgv_OrdCus.Name = "dgv_OrdCus";
            // 
            // dgv_CusOrdNo
            // 
            this.dgv_CusOrdNo.HeaderText = "客先注文№";
            this.dgv_CusOrdNo.Name = "dgv_CusOrdNo";
            this.dgv_CusOrdNo.ReadOnly = true;
            // 
            // dgv_ordPrjnm
            // 
            this.dgv_ordPrjnm.HeaderText = "案件名";
            this.dgv_ordPrjnm.Name = "dgv_ordPrjnm";
            // 
            // dgv_OrdContTyp
            // 
            this.dgv_OrdContTyp.HeaderText = "契約形態";
            this.dgv_OrdContTyp.Name = "dgv_OrdContTyp";
            this.dgv_OrdContTyp.Visible = false;
            // 
            // dgv_OrdEngId
            // 
            this.dgv_OrdEngId.HeaderText = "技術者ID";
            this.dgv_OrdEngId.Name = "dgv_OrdEngId";
            this.dgv_OrdEngId.Visible = false;
            // 
            // dgv_OrdEngNm
            // 
            this.dgv_OrdEngNm.HeaderText = "技術者";
            this.dgv_OrdEngNm.Name = "dgv_OrdEngNm";
            // 
            // dgv_OrdActkbn
            // 
            this.dgv_OrdActkbn.HeaderText = "精算区分";
            this.dgv_OrdActkbn.Name = "dgv_OrdActkbn";
            this.dgv_OrdActkbn.Visible = false;
            // 
            // dgv_OrdStrYMD
            // 
            this.dgv_OrdStrYMD.HeaderText = "開始期間";
            this.dgv_OrdStrYMD.Name = "dgv_OrdStrYMD";
            // 
            // dgv_OrdEndYMD
            // 
            this.dgv_OrdEndYMD.HeaderText = "終了期間";
            this.dgv_OrdEndYMD.Name = "dgv_OrdEndYMD";
            // 
            // dgv_OrdUlimit
            // 
            this.dgv_OrdUlimit.HeaderText = "下限時間";
            this.dgv_OrdUlimit.Name = "dgv_OrdUlimit";
            // 
            // dgv_OrdOlimit
            // 
            this.dgv_OrdOlimit.HeaderText = "上限時間";
            this.dgv_OrdOlimit.Name = "dgv_OrdOlimit";
            // 
            // dgv_OrdBaseRate
            // 
            this.dgv_OrdBaseRate.HeaderText = "基本単価";
            this.dgv_OrdBaseRate.Name = "dgv_OrdBaseRate";
            // 
            // dvg_OrdOvRate
            // 
            this.dvg_OrdOvRate.HeaderText = "超過単価";
            this.dvg_OrdOvRate.Name = "dvg_OrdOvRate";
            // 
            // dgv_OrdSubRate
            // 
            this.dgv_OrdSubRate.HeaderText = "控除単価";
            this.dgv_OrdSubRate.Name = "dgv_OrdSubRate";
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(788, 514);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(93, 43);
            this.btnOk.TabIndex = 2;
            this.btnOk.Text = "確定";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnEnd
            // 
            this.btnEnd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEnd.Location = new System.Drawing.Point(986, 514);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(93, 43);
            this.btnEnd.TabIndex = 4;
            this.btnEnd.Text = "終了";
            this.btnEnd.UseVisualStyleBackColor = true;
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // btnClr
            // 
            this.btnClr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClr.Location = new System.Drawing.Point(887, 515);
            this.btnClr.Name = "btnClr";
            this.btnClr.Size = new System.Drawing.Size(93, 43);
            this.btnClr.TabIndex = 3;
            this.btnClr.Text = "クリア";
            this.btnClr.UseVisualStyleBackColor = true;
            this.btnClr.Click += new System.EventHandler(this.btnClr_Click);
            // 
            // btnContinue
            // 
            this.btnContinue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnContinue.Location = new System.Drawing.Point(689, 514);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(93, 43);
            this.btnContinue.TabIndex = 5;
            this.btnContinue.Text = "継続";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // frmOrd020
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1091, 587);
            this.Controls.Add(this.btnContinue);
            this.Controls.Add(this.btnClr);
            this.Controls.Add(this.btnEnd);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.dgv_Result);
            this.Controls.Add(this.panel1);
            this.Name = "frmOrd020";
            this.Text = "frmOrd020";
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.dgv_Result, 0);
            this.Controls.SetChildIndex(this.btnOk, 0);
            this.Controls.SetChildIndex(this.btnEnd, 0);
            this.Controls.SetChildIndex(this.btnClr, 0);
            this.Controls.SetChildIndex(this.btnContinue, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private Common.ucNumTextBox txtOrderNoFrom;
        private Common.ucNumTextBox txtOrderNoTo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private Common.ucTextBoxEx txtProjectNm;
        private System.Windows.Forms.Button btnSearch;
        private Common.ucDataGridViewEx dgv_Result;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Button btnClr;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbEng;
        private System.Windows.Forms.RadioButton rdoEng2;
        private System.Windows.Forms.RadioButton rdoEng1;
        private Common.ucNumTextBox txtEngT;
        private System.Windows.Forms.Label label7;
        private Common.ucNumTextBox txtEngF;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cmbCus;
        private System.Windows.Forms.RadioButton rdoCus2;
        private System.Windows.Forms.RadioButton rdoCus1;
        private Common.ucNumTextBox txtCusT;
        private System.Windows.Forms.Label label8;
        private Common.ucNumTextBox txtCusF;
        private Common.ucYMTextbox mtbSaleYmT;
        private Common.ucYMTextbox mtbSaleYmF;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_ordNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_ordYMD;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdCusCd;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdCus;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_CusOrdNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_ordPrjnm;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdContTyp;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdEngId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdEngNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdActkbn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdStrYMD;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdEndYMD;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdUlimit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdOlimit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdBaseRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dvg_OrdOvRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrdSubRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private Common.ucTextBoxEx txtCusOrdNo;
        private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnContinue;
	}
}