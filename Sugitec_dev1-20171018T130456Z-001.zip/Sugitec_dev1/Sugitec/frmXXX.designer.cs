﻿namespace Sugitec
{
    partial class frmXXX
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			Sugitec.Common.HeaderCell headerCell1 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell2 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell3 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell4 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell5 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell6 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell7 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell8 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell9 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell10 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell11 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell12 = new Sugitec.Common.HeaderCell();
			Sugitec.Common.HeaderCell headerCell13 = new Sugitec.Common.HeaderCell();
			this.panel1 = new System.Windows.Forms.Panel();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.rdoBillIssued = new System.Windows.Forms.RadioButton();
			this.rdoBillUnpublished = new System.Windows.Forms.RadioButton();
			this.rdoBillAll = new System.Windows.Forms.RadioButton();
			this.txtSime = new Sugitec.Common.ucNumTextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.cmbCus = new System.Windows.Forms.ComboBox();
			this.rdoCus2 = new System.Windows.Forms.RadioButton();
			this.rdoCus1 = new System.Windows.Forms.RadioButton();
			this.txtCusT = new Sugitec.Common.ucNumTextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtCusF = new Sugitec.Common.ucNumTextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.cmbEng = new System.Windows.Forms.ComboBox();
			this.rdoEng2 = new System.Windows.Forms.RadioButton();
			this.rdoEng1 = new System.Windows.Forms.RadioButton();
			this.txtEngT = new Sugitec.Common.ucNumTextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtEngF = new Sugitec.Common.ucNumTextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.mtbBillingYm = new Sugitec.Common.ucYMTextbox();
			this.mtbBillingYmT = new Sugitec.Common.ucYMTextbox();
			this.mtbBillingYmF = new Sugitec.Common.ucYMTextbox();
			this.rdoReq2 = new System.Windows.Forms.RadioButton();
			this.rdoReq1 = new System.Windows.Forms.RadioButton();
			this.label14 = new System.Windows.Forms.Label();
			this.btnSearch = new System.Windows.Forms.Button();
			this.dgv_Result = new Sugitec.Common.ctlDataGridViewEx();
			this.btnMore = new System.Windows.Forms.Button();
			this.btnEnd = new System.Windows.Forms.Button();
			this.btnClr = new System.Windows.Forms.Button();
			this.btnOut = new System.Windows.Forms.Button();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.rdoPrint = new System.Windows.Forms.RadioButton();
			this.rdoPdf = new System.Windows.Forms.RadioButton();
			this.rdoExcel = new System.Windows.Forms.RadioButton();
			this.dgv_Sel = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.dgv_Month = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_Day = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_CusCd = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_PrjNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_EngId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_EngNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_CusNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_BillingAmt = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_Publish = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_SalesNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dgv_OrderNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel1.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).BeginInit();
			this.groupBox5.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.groupBox4);
			this.panel1.Controls.Add(this.txtSime);
			this.panel1.Controls.Add(this.label8);
			this.panel1.Controls.Add(this.label11);
			this.panel1.Controls.Add(this.groupBox3);
			this.panel1.Controls.Add(this.groupBox2);
			this.panel1.Controls.Add(this.groupBox1);
			this.panel1.Controls.Add(this.btnSearch);
			this.panel1.Location = new System.Drawing.Point(12, 43);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1044, 124);
			this.panel1.TabIndex = 0;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.rdoBillIssued);
			this.groupBox4.Controls.Add(this.rdoBillUnpublished);
			this.groupBox4.Controls.Add(this.rdoBillAll);
			this.groupBox4.Location = new System.Drawing.Point(817, 35);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(218, 47);
			this.groupBox4.TabIndex = 6;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "請求書";
			// 
			// rdoBillIssued
			// 
			this.rdoBillIssued.AutoSize = true;
			this.rdoBillIssued.Location = new System.Drawing.Point(146, 18);
			this.rdoBillIssued.Name = "rdoBillIssued";
			this.rdoBillIssued.Size = new System.Drawing.Size(67, 17);
			this.rdoBillIssued.TabIndex = 3;
			this.rdoBillIssued.TabStop = true;
			this.rdoBillIssued.Text = "発行済";
			this.rdoBillIssued.UseVisualStyleBackColor = true;
			// 
			// rdoBillUnpublished
			// 
			this.rdoBillUnpublished.AutoSize = true;
			this.rdoBillUnpublished.Location = new System.Drawing.Point(72, 18);
			this.rdoBillUnpublished.Name = "rdoBillUnpublished";
			this.rdoBillUnpublished.Size = new System.Drawing.Size(67, 17);
			this.rdoBillUnpublished.TabIndex = 2;
			this.rdoBillUnpublished.TabStop = true;
			this.rdoBillUnpublished.Text = "未発行";
			this.rdoBillUnpublished.UseVisualStyleBackColor = true;
			// 
			// rdoBillAll
			// 
			this.rdoBillAll.AutoSize = true;
			this.rdoBillAll.Location = new System.Drawing.Point(15, 18);
			this.rdoBillAll.Name = "rdoBillAll";
			this.rdoBillAll.Size = new System.Drawing.Size(53, 17);
			this.rdoBillAll.TabIndex = 0;
			this.rdoBillAll.TabStop = true;
			this.rdoBillAll.Text = "全て";
			this.rdoBillAll.UseVisualStyleBackColor = true;
			// 
			// txtSime
			// 
			this.txtSime.BackColor = System.Drawing.SystemColors.Window;
			this.txtSime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.txtSime.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
			this.txtSime.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.txtSime.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtSime.Format = null;
			this.txtSime.IllegalCharacter = null;
			this.txtSime.ImeMode = System.Windows.Forms.ImeMode.Disable;
			this.txtSime.Location = new System.Drawing.Point(862, 9);
			this.txtSime.MaxLength = 2;
			this.txtSime.Name = "txtSime";
			this.txtSime.OldText = null;
			this.txtSime.Size = new System.Drawing.Size(51, 20);
			this.txtSime.TabIndex = 4;
			this.txtSime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txtSime.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(823, 12);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(35, 13);
			this.label8.TabIndex = 3;
			this.label8.Text = "締日";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(919, 12);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(77, 13);
			this.label11.TabIndex = 5;
			this.label11.Text = "(末日：99)";
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.cmbCus);
			this.groupBox3.Controls.Add(this.rdoCus2);
			this.groupBox3.Controls.Add(this.rdoCus1);
			this.groupBox3.Controls.Add(this.txtCusT);
			this.groupBox3.Controls.Add(this.label2);
			this.groupBox3.Controls.Add(this.txtCusF);
			this.groupBox3.Location = new System.Drawing.Point(296, 12);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(252, 89);
			this.groupBox3.TabIndex = 2;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "得意先";
			// 
			// cmbCus
			// 
			this.cmbCus.FormattingEnabled = true;
			this.cmbCus.Location = new System.Drawing.Point(45, 24);
			this.cmbCus.Name = "cmbCus";
			this.cmbCus.Size = new System.Drawing.Size(197, 21);
			this.cmbCus.TabIndex = 1;
			// 
			// rdoCus2
			// 
			this.rdoCus2.AutoSize = true;
			this.rdoCus2.Location = new System.Drawing.Point(15, 57);
			this.rdoCus2.Name = "rdoCus2";
			this.rdoCus2.Size = new System.Drawing.Size(14, 13);
			this.rdoCus2.TabIndex = 2;
			this.rdoCus2.TabStop = true;
			this.rdoCus2.UseVisualStyleBackColor = true;
			// 
			// rdoCus1
			// 
			this.rdoCus1.AutoSize = true;
			this.rdoCus1.Location = new System.Drawing.Point(15, 27);
			this.rdoCus1.Name = "rdoCus1";
			this.rdoCus1.Size = new System.Drawing.Size(14, 13);
			this.rdoCus1.TabIndex = 0;
			this.rdoCus1.TabStop = true;
			this.rdoCus1.UseVisualStyleBackColor = true;
			// 
			// txtCusT
			// 
			this.txtCusT.BackColor = System.Drawing.SystemColors.Window;
			this.txtCusT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.txtCusT.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
			this.txtCusT.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.txtCusT.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtCusT.Format = null;
			this.txtCusT.IllegalCharacter = null;
			this.txtCusT.ImeMode = System.Windows.Forms.ImeMode.Disable;
			this.txtCusT.Location = new System.Drawing.Point(161, 54);
			this.txtCusT.MaxLength = 8;
			this.txtCusT.Name = "txtCusT";
			this.txtCusT.OldText = null;
			this.txtCusT.Size = new System.Drawing.Size(81, 20);
			this.txtCusT.TabIndex = 5;
			this.txtCusT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.txtCusT.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(132, 54);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(25, 20);
			this.label2.TabIndex = 4;
			this.label2.Text = "～";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtCusF
			// 
			this.txtCusF.BackColor = System.Drawing.SystemColors.Window;
			this.txtCusF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.txtCusF.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
			this.txtCusF.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.txtCusF.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtCusF.Format = null;
			this.txtCusF.IllegalCharacter = null;
			this.txtCusF.ImeMode = System.Windows.Forms.ImeMode.Disable;
			this.txtCusF.Location = new System.Drawing.Point(45, 54);
			this.txtCusF.MaxLength = 8;
			this.txtCusF.Name = "txtCusF";
			this.txtCusF.OldText = null;
			this.txtCusF.Size = new System.Drawing.Size(81, 20);
			this.txtCusF.TabIndex = 3;
			this.txtCusF.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.txtCusF.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.cmbEng);
			this.groupBox2.Controls.Add(this.rdoEng2);
			this.groupBox2.Controls.Add(this.rdoEng1);
			this.groupBox2.Controls.Add(this.txtEngT);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.txtEngF);
			this.groupBox2.Location = new System.Drawing.Point(559, 12);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(252, 89);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "技術者";
			// 
			// cmbEng
			// 
			this.cmbEng.FormattingEnabled = true;
			this.cmbEng.Location = new System.Drawing.Point(45, 24);
			this.cmbEng.Name = "cmbEng";
			this.cmbEng.Size = new System.Drawing.Size(187, 21);
			this.cmbEng.TabIndex = 1;
			// 
			// rdoEng2
			// 
			this.rdoEng2.AutoSize = true;
			this.rdoEng2.Location = new System.Drawing.Point(15, 57);
			this.rdoEng2.Name = "rdoEng2";
			this.rdoEng2.Size = new System.Drawing.Size(14, 13);
			this.rdoEng2.TabIndex = 2;
			this.rdoEng2.TabStop = true;
			this.rdoEng2.UseVisualStyleBackColor = true;
			// 
			// rdoEng1
			// 
			this.rdoEng1.AutoSize = true;
			this.rdoEng1.Location = new System.Drawing.Point(15, 27);
			this.rdoEng1.Name = "rdoEng1";
			this.rdoEng1.Size = new System.Drawing.Size(14, 13);
			this.rdoEng1.TabIndex = 0;
			this.rdoEng1.TabStop = true;
			this.rdoEng1.UseVisualStyleBackColor = true;
			// 
			// txtEngT
			// 
			this.txtEngT.BackColor = System.Drawing.SystemColors.Window;
			this.txtEngT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.txtEngT.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
			this.txtEngT.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.txtEngT.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtEngT.Format = null;
			this.txtEngT.IllegalCharacter = null;
			this.txtEngT.ImeMode = System.Windows.Forms.ImeMode.Disable;
			this.txtEngT.Location = new System.Drawing.Point(161, 54);
			this.txtEngT.MaxLength = 8;
			this.txtEngT.Name = "txtEngT";
			this.txtEngT.OldText = null;
			this.txtEngT.Size = new System.Drawing.Size(81, 20);
			this.txtEngT.TabIndex = 5;
			this.txtEngT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.txtEngT.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(132, 54);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(20, 20);
			this.label4.TabIndex = 4;
			this.label4.Text = "～";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtEngF
			// 
			this.txtEngF.BackColor = System.Drawing.SystemColors.Window;
			this.txtEngF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.txtEngF.CharacterType = Sugitec.Common.ucNumTextBox.emCharacterType.OnlyNumericCode;
			this.txtEngF.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.txtEngF.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtEngF.Format = null;
			this.txtEngF.IllegalCharacter = null;
			this.txtEngF.ImeMode = System.Windows.Forms.ImeMode.Disable;
			this.txtEngF.Location = new System.Drawing.Point(45, 54);
			this.txtEngF.MaxLength = 8;
			this.txtEngF.Name = "txtEngF";
			this.txtEngF.OldText = null;
			this.txtEngF.Size = new System.Drawing.Size(81, 20);
			this.txtEngF.TabIndex = 3;
			this.txtEngF.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.txtEngF.ZeroPadding = Sugitec.Common.ucNumTextBox.emPaddingType.Left;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.mtbBillingYm);
			this.groupBox1.Controls.Add(this.mtbBillingYmT);
			this.groupBox1.Controls.Add(this.mtbBillingYmF);
			this.groupBox1.Controls.Add(this.rdoReq2);
			this.groupBox1.Controls.Add(this.rdoReq1);
			this.groupBox1.Controls.Add(this.label14);
			this.groupBox1.Location = new System.Drawing.Point(20, 12);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(270, 89);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "請求年月";
			// 
			// mtbBillingYm
			// 
			this.mtbBillingYm.BackColor = System.Drawing.SystemColors.Window;
			this.mtbBillingYm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.mtbBillingYm.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.mtbBillingYm.ForeColor = System.Drawing.SystemColors.WindowText;
			this.mtbBillingYm.ImeMode = System.Windows.Forms.ImeMode.Disable;
			this.mtbBillingYm.Location = new System.Drawing.Point(40, 24);
			this.mtbBillingYm.Name = "mtbBillingYm";
			this.mtbBillingYm.OldValue = null;
			this.mtbBillingYm.Size = new System.Drawing.Size(97, 20);
			this.mtbBillingYm.TabIndex = 1;
			this.mtbBillingYm.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			// 
			// mtbBillingYmT
			// 
			this.mtbBillingYmT.BackColor = System.Drawing.SystemColors.Window;
			this.mtbBillingYmT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.mtbBillingYmT.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.mtbBillingYmT.ForeColor = System.Drawing.SystemColors.WindowText;
			this.mtbBillingYmT.ImeMode = System.Windows.Forms.ImeMode.Disable;
			this.mtbBillingYmT.Location = new System.Drawing.Point(166, 54);
			this.mtbBillingYmT.Name = "mtbBillingYmT";
			this.mtbBillingYmT.OldValue = null;
			this.mtbBillingYmT.Size = new System.Drawing.Size(97, 20);
			this.mtbBillingYmT.TabIndex = 5;
			this.mtbBillingYmT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			// 
			// mtbBillingYmF
			// 
			this.mtbBillingYmF.BackColor = System.Drawing.SystemColors.Window;
			this.mtbBillingYmF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.mtbBillingYmF.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.mtbBillingYmF.ForeColor = System.Drawing.SystemColors.WindowText;
			this.mtbBillingYmF.ImeMode = System.Windows.Forms.ImeMode.Disable;
			this.mtbBillingYmF.Location = new System.Drawing.Point(40, 54);
			this.mtbBillingYmF.Name = "mtbBillingYmF";
			this.mtbBillingYmF.OldValue = null;
			this.mtbBillingYmF.Size = new System.Drawing.Size(97, 20);
			this.mtbBillingYmF.TabIndex = 3;
			this.mtbBillingYmF.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			// 
			// rdoReq2
			// 
			this.rdoReq2.AutoSize = true;
			this.rdoReq2.Location = new System.Drawing.Point(11, 57);
			this.rdoReq2.Name = "rdoReq2";
			this.rdoReq2.Size = new System.Drawing.Size(14, 13);
			this.rdoReq2.TabIndex = 2;
			this.rdoReq2.TabStop = true;
			this.rdoReq2.UseVisualStyleBackColor = true;
			// 
			// rdoReq1
			// 
			this.rdoReq1.AutoSize = true;
			this.rdoReq1.Location = new System.Drawing.Point(11, 27);
			this.rdoReq1.Name = "rdoReq1";
			this.rdoReq1.Size = new System.Drawing.Size(14, 13);
			this.rdoReq1.TabIndex = 0;
			this.rdoReq1.TabStop = true;
			this.rdoReq1.UseVisualStyleBackColor = true;
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(141, 54);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(20, 20);
			this.label14.TabIndex = 4;
			this.label14.Text = "～";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnSearch
			// 
			this.btnSearch.Location = new System.Drawing.Point(940, 85);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new System.Drawing.Size(93, 32);
			this.btnSearch.TabIndex = 6;
			this.btnSearch.Text = "検索";
			this.btnSearch.UseVisualStyleBackColor = true;
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			// 
			// dgv_Result
			// 
			this.dgv_Result.AllowUserToAddRows = false;
			this.dgv_Result.AllowUserToDeleteRows = false;
			this.dgv_Result.AllowUserToResizeRows = false;
			this.dgv_Result.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.dgv_Result.ColumnHeaderBorderStyle = Sugitec.Common.ctlDataGridViewEx.HeaderCellBorderStyle.SingleLine;
			this.dgv_Result.ColumnHeaderRowCount = 1;
			this.dgv_Result.ColumnHeaderRowHeight = 20;
			this.dgv_Result.ColumnHeadersHeight = 22;
			this.dgv_Result.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgv_Sel,
            this.dgv_Month,
            this.dgv_Day,
            this.dgv_CusCd,
            this.dgv_PrjNm,
            this.dgv_EngId,
            this.dgv_EngNm,
            this.dgv_CusNm,
            this.dgv_BillingAmt,
            this.dgv_Publish,
            this.dgv_SalesNo,
            this.dgv_OrderNo});
			headerCell1.BackgroundColor = System.Drawing.Color.Empty;
			headerCell1.Column = 0;
			headerCell1.ColumnSpan = 1;
			headerCell1.ForeColor = System.Drawing.Color.Empty;
			headerCell1.Row = 0;
			headerCell1.RowSpan = 1;
			headerCell1.SortVisible = false;
			headerCell1.Text = "選";
			headerCell1.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			headerCell1.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell2.BackgroundColor = System.Drawing.Color.Empty;
			headerCell2.Column = 1;
			headerCell2.ColumnSpan = 1;
			headerCell2.ForeColor = System.Drawing.Color.Empty;
			headerCell2.Row = 0;
			headerCell2.RowSpan = 1;
			headerCell2.SortVisible = false;
			headerCell2.Text = "請求年月";
			headerCell2.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			headerCell2.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell3.BackgroundColor = System.Drawing.Color.Empty;
			headerCell3.Column = 2;
			headerCell3.ColumnSpan = 1;
			headerCell3.ForeColor = System.Drawing.Color.Empty;
			headerCell3.Row = 0;
			headerCell3.RowSpan = 1;
			headerCell3.SortVisible = false;
			headerCell3.Text = "請求№";
			headerCell3.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			headerCell3.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell4.BackgroundColor = System.Drawing.Color.Empty;
			headerCell4.Column = 3;
			headerCell4.ColumnSpan = 1;
			headerCell4.ForeColor = System.Drawing.Color.Empty;
			headerCell4.Row = 0;
			headerCell4.RowSpan = 1;
			headerCell4.SortVisible = false;
			headerCell4.Text = "枝番";
			headerCell4.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			headerCell4.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell5.BackgroundColor = System.Drawing.Color.Empty;
			headerCell5.Column = 4;
			headerCell5.ColumnSpan = 1;
			headerCell5.ForeColor = System.Drawing.Color.Empty;
			headerCell5.Row = 0;
			headerCell5.RowSpan = 1;
			headerCell5.SortVisible = false;
			headerCell5.Text = "得意先コード";
			headerCell5.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.NotSet;
			headerCell5.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell6.BackgroundColor = System.Drawing.Color.Empty;
			headerCell6.Column = 5;
			headerCell6.ColumnSpan = 1;
			headerCell6.ForeColor = System.Drawing.Color.Empty;
			headerCell6.Row = 0;
			headerCell6.RowSpan = 1;
			headerCell6.SortVisible = false;
			headerCell6.Text = "得意先";
			headerCell6.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			headerCell6.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell7.BackgroundColor = System.Drawing.Color.Empty;
			headerCell7.Column = 6;
			headerCell7.ColumnSpan = 1;
			headerCell7.ForeColor = System.Drawing.Color.Empty;
			headerCell7.Row = 0;
			headerCell7.RowSpan = 1;
			headerCell7.SortVisible = false;
			headerCell7.Text = "案件名";
			headerCell7.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			headerCell7.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell8.BackgroundColor = System.Drawing.Color.Empty;
			headerCell8.Column = 7;
			headerCell8.ColumnSpan = 1;
			headerCell8.ForeColor = System.Drawing.Color.Empty;
			headerCell8.Row = 0;
			headerCell8.RowSpan = 1;
			headerCell8.SortVisible = false;
			headerCell8.Text = "技術者ID";
			headerCell8.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.NotSet;
			headerCell8.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell9.BackgroundColor = System.Drawing.Color.Empty;
			headerCell9.Column = 8;
			headerCell9.ColumnSpan = 1;
			headerCell9.ForeColor = System.Drawing.Color.Empty;
			headerCell9.Row = 0;
			headerCell9.RowSpan = 1;
			headerCell9.SortVisible = false;
			headerCell9.Text = "技術者";
			headerCell9.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			headerCell9.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell10.BackgroundColor = System.Drawing.Color.Empty;
			headerCell10.Column = 9;
			headerCell10.ColumnSpan = 1;
			headerCell10.ForeColor = System.Drawing.Color.Empty;
			headerCell10.Row = 0;
			headerCell10.RowSpan = 1;
			headerCell10.SortVisible = false;
			headerCell10.Text = "請求金額";
			headerCell10.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			headerCell10.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell11.BackgroundColor = System.Drawing.Color.Empty;
			headerCell11.Column = 10;
			headerCell11.ColumnSpan = 1;
			headerCell11.ForeColor = System.Drawing.Color.Empty;
			headerCell11.Row = 0;
			headerCell11.RowSpan = 1;
			headerCell11.SortVisible = false;
			headerCell11.Text = "請求書";
			headerCell11.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			headerCell11.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell12.BackgroundColor = System.Drawing.Color.Empty;
			headerCell12.Column = 11;
			headerCell12.ColumnSpan = 1;
			headerCell12.ForeColor = System.Drawing.Color.Empty;
			headerCell12.Row = 0;
			headerCell12.RowSpan = 1;
			headerCell12.SortVisible = false;
			headerCell12.Text = "売上№";
			headerCell12.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			headerCell12.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			headerCell13.BackgroundColor = System.Drawing.Color.Empty;
			headerCell13.Column = 12;
			headerCell13.ColumnSpan = 1;
			headerCell13.ForeColor = System.Drawing.Color.Empty;
			headerCell13.Row = 0;
			headerCell13.RowSpan = 1;
			headerCell13.SortVisible = false;
			headerCell13.Text = "受注№";
			headerCell13.TextAlign = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			headerCell13.WrapMode = System.Windows.Forms.DataGridViewTriState.NotSet;
			this.dgv_Result.HeaderCells.Add(headerCell1);
			this.dgv_Result.HeaderCells.Add(headerCell2);
			this.dgv_Result.HeaderCells.Add(headerCell3);
			this.dgv_Result.HeaderCells.Add(headerCell4);
			this.dgv_Result.HeaderCells.Add(headerCell5);
			this.dgv_Result.HeaderCells.Add(headerCell6);
			this.dgv_Result.HeaderCells.Add(headerCell7);
			this.dgv_Result.HeaderCells.Add(headerCell8);
			this.dgv_Result.HeaderCells.Add(headerCell9);
			this.dgv_Result.HeaderCells.Add(headerCell10);
			this.dgv_Result.HeaderCells.Add(headerCell11);
			this.dgv_Result.HeaderCells.Add(headerCell12);
			this.dgv_Result.HeaderCells.Add(headerCell13);
			this.dgv_Result.Location = new System.Drawing.Point(12, 174);
			this.dgv_Result.Name = "dgv_Result";
			this.dgv_Result.RowHeadersVisible = false;
			this.dgv_Result.RowTemplate.Height = 21;
			this.dgv_Result.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgv_Result.Size = new System.Drawing.Size(1044, 275);
			this.dgv_Result.TabIndex = 1;
			// 
			// btnMore
			// 
			this.btnMore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnMore.Location = new System.Drawing.Point(765, 455);
			this.btnMore.Name = "btnMore";
			this.btnMore.Size = new System.Drawing.Size(93, 43);
			this.btnMore.TabIndex = 4;
			this.btnMore.Text = "詳細表示";
			this.btnMore.UseVisualStyleBackColor = true;
			this.btnMore.Click += new System.EventHandler(this.btnMore_Click);
			// 
			// btnEnd
			// 
			this.btnEnd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnEnd.Location = new System.Drawing.Point(963, 455);
			this.btnEnd.Name = "btnEnd";
			this.btnEnd.Size = new System.Drawing.Size(93, 43);
			this.btnEnd.TabIndex = 6;
			this.btnEnd.Text = "終了";
			this.btnEnd.UseVisualStyleBackColor = true;
			this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
			// 
			// btnClr
			// 
			this.btnClr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnClr.Location = new System.Drawing.Point(864, 455);
			this.btnClr.Name = "btnClr";
			this.btnClr.Size = new System.Drawing.Size(93, 43);
			this.btnClr.TabIndex = 5;
			this.btnClr.Text = "クリア";
			this.btnClr.UseVisualStyleBackColor = true;
			this.btnClr.Click += new System.EventHandler(this.btnClr_Click);
			// 
			// btnOut
			// 
			this.btnOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnOut.Location = new System.Drawing.Point(666, 455);
			this.btnOut.Name = "btnOut";
			this.btnOut.Size = new System.Drawing.Size(93, 43);
			this.btnOut.TabIndex = 3;
			this.btnOut.Text = "請求書発行";
			this.btnOut.UseVisualStyleBackColor = true;
			this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.rdoPrint);
			this.groupBox5.Controls.Add(this.rdoPdf);
			this.groupBox5.Controls.Add(this.rdoExcel);
			this.groupBox5.Location = new System.Drawing.Point(414, 455);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(240, 42);
			this.groupBox5.TabIndex = 2;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "出力形式";
			// 
			// rdoPrint
			// 
			this.rdoPrint.AutoSize = true;
			this.rdoPrint.Location = new System.Drawing.Point(175, 21);
			this.rdoPrint.Name = "rdoPrint";
			this.rdoPrint.Size = new System.Drawing.Size(53, 17);
			this.rdoPrint.TabIndex = 2;
			this.rdoPrint.Text = "印刷";
			this.rdoPrint.UseVisualStyleBackColor = true;
			// 
			// rdoPdf
			// 
			this.rdoPdf.AutoSize = true;
			this.rdoPdf.Location = new System.Drawing.Point(104, 21);
			this.rdoPdf.Name = "rdoPdf";
			this.rdoPdf.Size = new System.Drawing.Size(46, 17);
			this.rdoPdf.TabIndex = 1;
			this.rdoPdf.Text = "PDF";
			this.rdoPdf.UseVisualStyleBackColor = true;
			// 
			// rdoExcel
			// 
			this.rdoExcel.AutoSize = true;
			this.rdoExcel.Location = new System.Drawing.Point(21, 21);
			this.rdoExcel.Name = "rdoExcel";
			this.rdoExcel.Size = new System.Drawing.Size(60, 17);
			this.rdoExcel.TabIndex = 0;
			this.rdoExcel.Text = "Excel";
			this.rdoExcel.UseVisualStyleBackColor = true;
			// 
			// dgv_Sel
			// 
			this.dgv_Sel.HeaderText = "選";
			this.dgv_Sel.Name = "dgv_Sel";
			this.dgv_Sel.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.dgv_Sel.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
			this.dgv_Sel.Width = 50;
			// 
			// dgv_Month
			// 
			this.dgv_Month.HeaderText = "月";
			this.dgv_Month.Name = "dgv_Month";
			this.dgv_Month.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// dgv_Day
			// 
			this.dgv_Day.HeaderText = "日";
			this.dgv_Day.Name = "dgv_Day";
			this.dgv_Day.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// dgv_CusCd
			// 
			this.dgv_CusCd.HeaderText = "得意先コード";
			this.dgv_CusCd.Name = "dgv_CusCd";
			this.dgv_CusCd.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dgv_CusCd.Visible = false;
			// 
			// dgv_PrjNm
			// 
			this.dgv_PrjNm.HeaderText = "訪問先";
			this.dgv_PrjNm.Name = "dgv_PrjNm";
			this.dgv_PrjNm.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// dgv_EngId
			// 
			this.dgv_EngId.HeaderText = "技術者ID";
			this.dgv_EngId.Name = "dgv_EngId";
			this.dgv_EngId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dgv_EngId.Visible = false;
			// 
			// dgv_EngNm
			// 
			this.dgv_EngNm.HeaderText = "今回対象の会社";
			this.dgv_EngNm.Name = "dgv_EngNm";
			this.dgv_EngNm.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// dgv_CusNm
			// 
			this.dgv_CusNm.HeaderText = "今回対象の技術者";
			this.dgv_CusNm.Name = "dgv_CusNm";
			this.dgv_CusNm.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// dgv_BillingAmt
			// 
			this.dgv_BillingAmt.HeaderText = "金額";
			this.dgv_BillingAmt.Name = "dgv_BillingAmt";
			this.dgv_BillingAmt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// dgv_Publish
			// 
			this.dgv_Publish.HeaderText = "請求書";
			this.dgv_Publish.Name = "dgv_Publish";
			this.dgv_Publish.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// dgv_SalesNo
			// 
			this.dgv_SalesNo.HeaderText = "売上№";
			this.dgv_SalesNo.Name = "dgv_SalesNo";
			this.dgv_SalesNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// dgv_OrderNo
			// 
			this.dgv_OrderNo.HeaderText = "受注№";
			this.dgv_OrderNo.Name = "dgv_OrderNo";
			this.dgv_OrderNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			// 
			// frmXXX
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1068, 528);
			this.Controls.Add(this.groupBox5);
			this.Controls.Add(this.btnOut);
			this.Controls.Add(this.btnClr);
			this.Controls.Add(this.btnEnd);
			this.Controls.Add(this.btnMore);
			this.Controls.Add(this.dgv_Result);
			this.Controls.Add(this.panel1);
			this.Name = "frmXXX";
			this.Text = "frmSal020";
			this.Controls.SetChildIndex(this.panel1, 0);
			this.Controls.SetChildIndex(this.dgv_Result, 0);
			this.Controls.SetChildIndex(this.btnMore, 0);
			this.Controls.SetChildIndex(this.btnEnd, 0);
			this.Controls.SetChildIndex(this.btnClr, 0);
			this.Controls.SetChildIndex(this.btnOut, 0);
			this.Controls.SetChildIndex(this.groupBox5, 0);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).EndInit();
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Common.ucNumTextBox txtEngT;
        private System.Windows.Forms.Label label4;
        private Common.ucNumTextBox txtEngF;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnSearch;
        private Common.ctlDataGridViewEx dgv_Result;
        private System.Windows.Forms.Button btnMore;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Button btnClr;
        private Common.ucYMTextbox mtbBillingYmT;
        private Common.ucYMTextbox mtbBillingYmF;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cmbCus;
        private System.Windows.Forms.RadioButton rdoCus2;
        private System.Windows.Forms.RadioButton rdoCus1;
        private Common.ucNumTextBox txtCusT;
        private System.Windows.Forms.Label label2;
        private Common.ucNumTextBox txtCusF;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbEng;
        private System.Windows.Forms.RadioButton rdoEng2;
        private System.Windows.Forms.RadioButton rdoEng1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoReq2;
        private System.Windows.Forms.RadioButton rdoReq1;
        private System.Windows.Forms.Label label11;
        private Common.ucNumTextBox txtSime;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdoBillIssued;
        private System.Windows.Forms.RadioButton rdoBillUnpublished;
        private System.Windows.Forms.RadioButton rdoBillAll;
        private System.Windows.Forms.Button btnOut;
		public Common.ucYMTextbox mtbBillingYm;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdoPrint;
        private System.Windows.Forms.RadioButton rdoPdf;
        private System.Windows.Forms.RadioButton rdoExcel;
		private System.Windows.Forms.DataGridViewCheckBoxColumn dgv_Sel;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_Month;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_Day;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_CusCd;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_PrjNm;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_EngId;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_EngNm;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_CusNm;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_BillingAmt;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_Publish;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_SalesNo;
		private System.Windows.Forms.DataGridViewTextBoxColumn dgv_OrderNo;
	}
}